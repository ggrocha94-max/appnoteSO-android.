# appnoteSO — APK Android (offline-first)

O app Android usa uma entrada Vite separada (`android.html`) para empacotar a interface React como arquivos locais em `www/`. Não depende do servidor TanStack/Nitro para abrir notas, alarmes ou navegação. A previsão é atualizada online e a última resposta é guardada em `localStorage` para consulta offline.

## O que está preparado

- Capacitor 7 com `appId` `com.appnoteso.mobile` e nome `appnoteSO`.
- Build estático local: `npm run build:android-web` produz `www/`.
- Notas e preferências permanecem no `localStorage` do WebView do app.
- Cache persistente da previsão por cidade/coordenadas; se a internet falhar, a última previsão salva continua disponível e pode estar desatualizada.
- Integração com Capacitor Local Notifications: tenta sincronizar alarmes semanais/únicos e lembretes de notas com notificações Android. O Android pode exigir permissão de notificações; comportamento de som/execução exata depende da versão do Android e das restrições de bateria do fabricante. Isso ainda precisa ser testado em aparelho real e não equivale a um serviço de alarme contínuo em tela cheia.
- GitHub Actions em `.github/workflows/android-apk.yml` para compilar e publicar o APK de depuração como artefato.

## Gerar o APK com GitHub Actions

1. Envie este projeto para um repositório GitHub.
2. Abra a aba **Actions** do repositório.
3. Selecione **Build appnoteSO Android APK** e toque em **Run workflow** (ou envie um commit para `main`).
4. Quando terminar, abra a execução e baixe o artefato `appnoteSO-debug-apk`.
5. Extraia o ZIP do artefato e instale `app-debug.apk` no Android. Talvez seja necessário permitir a instalação dessa fonte.

## Compilar localmente

Requer Node.js 22, JDK 21 e Android SDK/Android Studio:

```sh
npm ci
npm run build:android-web
npx cap add android   # apenas na primeira vez
npx cap sync android
cd android
./gradlew assembleDebug
```

APK esperado: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Limitações honestas

Este ambiente de edição não tem Android SDK instalado e não conseguiu completar a instalação npm durante a sessão, então nenhum APK foi compilado/testado aqui. Antes de distribuir, teste: reinicialização do aparelho, permissões de notificações, alarmes com app fechado, alterações de fuso horário, modo economia de bateria e persistência das notas após atualizar o app. Alarmes críticos podem exigir a permissão de alarmes exatos e uma implementação Android nativa adicional.
