import React from "react";
import { createRoot } from "react-dom/client";
import { App } from "@/components/app";
import "@/styles.css";
import { useApp } from "@/lib/store";
import { syncNativeSchedules } from "@/lib/native-notifications";

const root = document.getElementById("root");
if (!root) throw new Error("Elemento root não encontrado");

createRoot(root).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);

// Reconciles native schedules on launch and whenever persisted alarms/notes change.
let previous = "";
useApp.subscribe((state) => {
  const snapshot = JSON.stringify({ alarms: state.alarms, notes: state.notes });
  if (snapshot === previous) return;
  previous = snapshot;
  void syncNativeSchedules(state.alarms, state.notes).catch((error) => {
    console.warn("Não foi possível sincronizar notificações nativas", error);
  });
});
