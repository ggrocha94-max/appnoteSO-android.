import type { Place } from "@/lib/store";

export type SkyIcon =
  | "sun"
  | "moon"
  | "cloud-sun"
  | "cloud-moon"
  | "cloud"
  | "fog"
  | "drizzle"
  | "rain"
  | "snow"
  | "storm";

export type HourPoint = {
  label: string;
  temp: number;
  pop: number;
  code: number;
  isDay: boolean;
};

export type DayPoint = {
  label: string;
  max: number;
  min: number;
  pop: number;
  code: number;
};

export type Forecast = {
  fetchedAt: number;
  offsetSeconds: number;
  current: {
    temp: number;
    apparent: number;
    humidity: number;
    wind: number;
    code: number;
    isDay: boolean;
  };
  hours: HourPoint[];
  days: DayPoint[];
};

const SHORT_DAYS = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];

type Cache = { key: string; at: number; data: Forecast };
let cache: Cache | null = null;

const FRESH_MS = 20 * 60 * 1000;
const WEATHER_CACHE_PREFIX = "appnoteso-weather-v1:";

function readSavedForecast(key: string): Cache | null {
  try {
    if (typeof localStorage === "undefined") return null;
    const raw = localStorage.getItem(WEATHER_CACHE_PREFIX + key);
    if (!raw) return null;
    const saved = JSON.parse(raw) as Cache;
    if (saved.key !== key || typeof saved.at !== "number" || !saved.data?.current || !Array.isArray(saved.data.days)) return null;
    return saved;
  } catch {
    return null;
  }
}

function saveForecast(entry: Cache): void {
  cache = entry;
  try {
    if (typeof localStorage !== "undefined") localStorage.setItem(WEATHER_CACHE_PREFIX + entry.key, JSON.stringify(entry));
  } catch {
    // Storage may be unavailable or full; in-memory forecast remains usable.
  }
}

export function describeWeather(code: number, isDay: boolean): { label: string; icon: SkyIcon } {
  if (code === 0) return { label: "Céu limpo", icon: isDay ? "sun" : "moon" };
  if (code === 1 || code === 2) {
    return { label: code === 1 ? "Quase limpo" : "Parcialmente nublado", icon: isDay ? "cloud-sun" : "cloud-moon" };
  }
  if (code === 3) return { label: "Nublado", icon: "cloud" };
  if (code === 45 || code === 48) return { label: "Neblina", icon: "fog" };
  if (code >= 51 && code <= 57) return { label: "Garoa", icon: "drizzle" };
  if (code >= 61 && code <= 67) return { label: "Chuva", icon: "rain" };
  if (code >= 80 && code <= 82) return { label: "Pancadas", icon: "rain" };
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return { label: "Neve", icon: "snow" };
  if (code >= 95) return { label: "Trovoada", icon: "storm" };
  return { label: "Tempo instável", icon: "cloud" };
}

function cacheKey(place: Place): string {
  return `${place.latitude.toFixed(2)},${place.longitude.toFixed(2)}`;
}

export function peekForecast(place: Place): Forecast | null {
  const key = cacheKey(place);
  const saved = cache?.key === key ? cache : readSavedForecast(key);
  if (!saved) return null;
  cache = saved;
  // Show even stale data offline; loadForecast will refresh it when possible.
  return saved.data;
}

function asNum(value: unknown): number | null {
  const number = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
  return Number.isFinite(number) ? number : null;
}

function parseLocal(value: string, offsetSeconds: number): number | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/.exec(value);
  if (!match) return null;
  const asUtc = Date.UTC(
    Number(match[1]),
    Number(match[2]) - 1,
    Number(match[3]),
    match[4] ? Number(match[4]) : 0,
    match[5] ? Number(match[5]) : 0,
  );
  return asUtc - offsetSeconds * 1000;
}

type Parts = { year: number; month: number; day: number; hour: number; weekday: number };

function partsInZone(ts: number, offsetSeconds: number): Parts {
  const shifted = new Date(ts + offsetSeconds * 1000);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth(),
    day: shifted.getUTCDate(),
    hour: shifted.getUTCHours(),
    weekday: shifted.getUTCDay(),
  };
}

function shiftDay(parts: Parts, days: number): { year: number; month: number; day: number } {
  const next = new Date(Date.UTC(parts.year, parts.month, parts.day + days));
  return { year: next.getUTCFullYear(), month: next.getUTCMonth(), day: next.getUTCDate() };
}

function sameDate(a: { year: number; month: number; day: number }, b: { year: number; month: number; day: number }) {
  return a.year === b.year && a.month === b.month && a.day === b.day;
}

export async function searchCities(query: string, signal?: AbortSignal): Promise<Place[]> {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.searchParams.set("name", query);
  url.searchParams.set("count", "5");
  url.searchParams.set("language", "pt");
  url.searchParams.set("format", "json");
  const response = await fetch(url, { signal });
  if (!response.ok) throw new Error("busca");
  const data = (await response.json()) as { results?: unknown };
  if (!Array.isArray(data.results)) return [];
  const places: Place[] = [];
  for (const item of data.results) {
    if (!item || typeof item !== "object") continue;
    const row = item as Record<string, unknown>;
    const latitude = asNum(row.latitude);
    const longitude = asNum(row.longitude);
    if (latitude == null || longitude == null || typeof row.name !== "string") continue;
    places.push({
      id: typeof row.id === "number" ? row.id : Math.round(latitude * 1000),
      name: row.name,
      admin1: typeof row.admin1 === "string" ? row.admin1 : "",
      country: typeof row.country === "string" ? row.country : "",
      latitude,
      longitude,
    });
  }
  return places;
}

export async function placeFromCoords(latitude: number, longitude: number, signal?: AbortSignal): Promise<Place> {
  let name = "Onde você está";
  let admin1 = "";
  let country = "";
  try {
    const url = new URL("https://api.bigdatacloud.net/data/reverse-geocode-client");
    url.searchParams.set("latitude", String(latitude));
    url.searchParams.set("longitude", String(longitude));
    url.searchParams.set("localityLanguage", "pt");
    const response = await fetch(url, { signal });
    if (response.ok) {
      const data = (await response.json()) as Record<string, unknown>;
      const city = typeof data.city === "string" && data.city ? data.city : "";
      const locality = typeof data.locality === "string" ? data.locality : "";
      name = city || locality || name;
      admin1 = typeof data.principalSubdivision === "string" ? data.principalSubdivision : "";
      country = typeof data.countryName === "string" ? data.countryName : "";
    }
  } catch (error) {
    if (signal?.aborted) throw error;
  }
  return {
    id: Math.round(latitude * 1000) * 1_000_000 + Math.round(longitude * 1000),
    name,
    admin1,
    country,
    latitude,
    longitude,
  };
}

export async function loadForecast(place: Place, signal?: AbortSignal, force = false): Promise<Forecast> {
  const key = cacheKey(place);
  const saved = cache?.key === key ? cache : readSavedForecast(key);
  if (saved) cache = saved;
  if (!force && saved && Date.now() - saved.at < FRESH_MS) return saved.data;

  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(place.latitude));
  url.searchParams.set("longitude", String(place.longitude));
  url.searchParams.set(
    "current",
    "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,is_day",
  );
  url.searchParams.set("hourly", "temperature_2m,precipitation_probability,weather_code,is_day");
  url.searchParams.set("daily", "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max");
  url.searchParams.set("timezone", "auto");
  url.searchParams.set("forecast_days", "5");
  url.searchParams.set("wind_speed_unit", "kmh");
  url.searchParams.set("temperature_unit", "celsius");

  let data: Record<string, unknown>;
  try {
    const response = await fetch(url, { signal });
    if (!response.ok) throw new Error("previsão");
    data = (await response.json()) as Record<string, unknown>;
  } catch (error) {
    if (signal?.aborted) throw error;
    if (saved) return saved.data;
    throw error;
  }
  const offsetSeconds = asNum(data.utc_offset_seconds) ?? 0;
  const current = data.current as Record<string, unknown> | undefined;
  const temp = asNum(current?.temperature_2m);
  const apparent = asNum(current?.apparent_temperature);
  const humidity = asNum(current?.relative_humidity_2m);
  const wind = asNum(current?.wind_speed_10m);
  const code = asNum(current?.weather_code);
  if (!current || temp == null || apparent == null || humidity == null || wind == null || code == null) {
    throw new Error("previsão");
  }

  const hourly = data.hourly as Record<string, unknown> | undefined;
  const hourlyTime = Array.isArray(hourly?.time) ? hourly.time : [];
  const hourlyTemp = Array.isArray(hourly?.temperature_2m) ? hourly.temperature_2m : [];
  const hourlyPop = Array.isArray(hourly?.precipitation_probability) ? hourly.precipitation_probability : [];
  const hourlyCode = Array.isArray(hourly?.weather_code) ? hourly.weather_code : [];
  const hourlyDay = Array.isArray(hourly?.is_day) ? hourly.is_day : [];
  const now = Date.now();
  const hours: HourPoint[] = [];
  for (let index = 0; index < hourlyTime.length; index += 1) {
    if (typeof hourlyTime[index] !== "string") continue;
    const time = parseLocal(hourlyTime[index] as string, offsetSeconds);
    const hourTemp = asNum(hourlyTemp[index]);
    const hourCode = asNum(hourlyCode[index]);
    if (time == null || hourTemp == null || hourCode == null) continue;
    if (time < now - 30 * 60 * 1000) continue;
    const zoned = partsInZone(time, offsetSeconds);
    hours.push({
      label: `${zoned.hour}h`,
      temp: Math.round(hourTemp),
      pop: Math.round(asNum(hourlyPop[index]) ?? 0),
      code: hourCode,
      isDay: hourlyDay[index] !== 0,
    });
    if (hours.length === 18) break;
  }

  const daily = data.daily as Record<string, unknown> | undefined;
  const dailyTime = Array.isArray(daily?.time) ? daily.time : [];
  const dailyCode = Array.isArray(daily?.weather_code) ? daily.weather_code : [];
  const dailyMax = Array.isArray(daily?.temperature_2m_max) ? daily.temperature_2m_max : [];
  const dailyMin = Array.isArray(daily?.temperature_2m_min) ? daily.temperature_2m_min : [];
  const dailyPop = Array.isArray(daily?.precipitation_probability_max) ? daily.precipitation_probability_max : [];
  const today = partsInZone(now, offsetSeconds);
  const tomorrow = shiftDay(today, 1);
  const days: DayPoint[] = [];
  for (let index = 0; index < dailyTime.length; index += 1) {
    if (typeof dailyTime[index] !== "string") continue;
    const time = parseLocal(dailyTime[index] as string, offsetSeconds);
    const max = asNum(dailyMax[index]);
    const min = asNum(dailyMin[index]);
    const dayCode = asNum(dailyCode[index]);
    if (time == null || max == null || min == null || dayCode == null) continue;
    const zoned = partsInZone(time, offsetSeconds);
    let label = SHORT_DAYS[zoned.weekday] ?? "";
    if (sameDate(zoned, today)) label = "hoje";
    else if (sameDate(zoned, tomorrow)) label = "amanhã";
    days.push({
      label,
      max: Math.round(max),
      min: Math.round(min),
      pop: Math.round(asNum(dailyPop[index]) ?? 0),
      code: dayCode,
    });
  }

  const forecast: Forecast = {
    fetchedAt: Date.now(),
    offsetSeconds,
    current: {
      temp: Math.round(temp),
      apparent: Math.round(apparent),
      humidity: Math.round(humidity),
      wind: Math.round(wind),
      code,
      isDay: current.is_day !== 0,
    },
    hours,
    days,
  };
  saveForecast({ key, at: forecast.fetchedAt, data: forecast });
  return forecast;
}
