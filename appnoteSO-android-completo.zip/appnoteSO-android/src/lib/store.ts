import { useEffect, useState } from "react";
import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export type ViewName = "notas" | "alarme" | "tempo";

export type Note = {
  id: string;
  body: string;
  createdAt: number;
  updatedAt: number;
  reminderAt: number | null;
  reminderFired: boolean;
};

export type Alarm = {
  id: string;
  label: string;
  hour: number;
  minute: number;
  enabled: boolean;
  /** 0 = domingo … 6 = sábado. Vazio = toca uma vez. */
  days: number[];
  lastFiredKey: string | null;
  snoozeUntil: number | null;
  onceDone: boolean;
};

export type Place = {
  id: number;
  name: string;
  admin1: string;
  country: string;
  latitude: number;
  longitude: number;
};

type AppState = {
  view: ViewName;
  notes: Note[];
  alarms: Alarm[];
  place: Place | null;
  draft: string;
  draftReminder: string;
  inbox: string[];
  notifyDismissed: boolean;
  notifyPrompt: boolean;
  setView: (view: ViewName) => void;
  setDraft: (draft: string) => void;
  setDraftReminder: (value: string) => void;
  clearDraft: () => void;
  addNote: (note: Note) => void;
  updateNote: (id: string, patch: Partial<Omit<Note, "id" | "createdAt">>) => void;
  deleteNote: (id: string) => void;
  markReminderFired: (id: string) => void;
  pushInbox: (id: string) => void;
  dismissInbox: (id: string) => void;
  addAlarm: (alarm: Alarm) => void;
  patchAlarm: (id: string, patch: Partial<Omit<Alarm, "id">>) => void;
  deleteAlarm: (id: string) => void;
  setPlace: (place: Place | null) => void;
  setNotifyPrompt: (value: boolean) => void;
  dismissNotify: () => void;
};

const NOTE_LIMIT = 12_000;

function cleanNote(value: unknown): Note | null {
  if (!value || typeof value !== "object") return null;
  const note = value as Record<string, unknown>;
  if (typeof note.id !== "string" || typeof note.body !== "string") return null;
  const createdAt = typeof note.createdAt === "number" ? note.createdAt : Date.now();
  return {
    id: note.id,
    body: note.body.slice(0, NOTE_LIMIT),
    createdAt,
    updatedAt: typeof note.updatedAt === "number" ? note.updatedAt : createdAt,
    reminderAt: typeof note.reminderAt === "number" ? note.reminderAt : null,
    reminderFired: note.reminderFired === true,
  };
}

function cleanAlarm(value: unknown): Alarm | null {
  if (!value || typeof value !== "object") return null;
  const alarm = value as Record<string, unknown>;
  if (typeof alarm.id !== "string") return null;
  const hour = typeof alarm.hour === "number" ? alarm.hour : -1;
  const minute = typeof alarm.minute === "number" ? alarm.minute : -1;
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  const days = Array.isArray(alarm.days)
    ? [...new Set(alarm.days.filter((day): day is number => typeof day === "number" && day >= 0 && day <= 6))].sort(
        (a, b) => a - b,
      )
    : [];
  return {
    id: alarm.id,
    label: typeof alarm.label === "string" ? alarm.label.slice(0, 80) : "",
    hour,
    minute,
    enabled: alarm.enabled !== false,
    days,
    lastFiredKey: typeof alarm.lastFiredKey === "string" ? alarm.lastFiredKey : null,
    snoozeUntil: typeof alarm.snoozeUntil === "number" ? alarm.snoozeUntil : null,
    onceDone: alarm.onceDone === true,
  };
}

function cleanPlace(value: unknown): Place | null {
  if (!value || typeof value !== "object") return null;
  const place = value as Record<string, unknown>;
  if (typeof place.latitude !== "number" || typeof place.longitude !== "number") return null;
  if (!Number.isFinite(place.latitude) || !Number.isFinite(place.longitude)) return null;
  return {
    id: typeof place.id === "number" ? place.id : Math.round(place.latitude * 1000),
    name: typeof place.name === "string" && place.name ? place.name : "Cidade",
    admin1: typeof place.admin1 === "string" ? place.admin1 : "",
    country: typeof place.country === "string" ? place.country : "",
    latitude: place.latitude,
    longitude: place.longitude,
  };
}

export function uid(): string {
  return crypto.randomUUID();
}

export const useApp = create<AppState>()(
  persist(
    (set) => ({
      view: "notas",
      notes: [],
      alarms: [],
      place: null,
      draft: "",
      draftReminder: "",
      inbox: [],
      notifyDismissed: false,
      notifyPrompt: false,
      setView: (view) => set({ view }),
      setDraft: (draft) => set({ draft: draft.slice(0, NOTE_LIMIT) }),
      setDraftReminder: (draftReminder) => set({ draftReminder }),
      clearDraft: () => set({ draft: "", draftReminder: "" }),
      addNote: (note) => set((state) => ({ notes: [note, ...state.notes] })),
      updateNote: (id, patch) =>
        set((state) => ({
          notes: state.notes.map((note) => (note.id === id ? { ...note, ...patch } : note)),
        })),
      deleteNote: (id) =>
        set((state) => ({
          notes: state.notes.filter((note) => note.id !== id),
          inbox: state.inbox.filter((item) => item !== id),
        })),
      markReminderFired: (id) =>
        set((state) => ({
          notes: state.notes.map((note) => (note.id === id ? { ...note, reminderFired: true } : note)),
        })),
      pushInbox: (id) =>
        set((state) => (state.inbox.includes(id) ? state : { inbox: [id, ...state.inbox].slice(0, 5) })),
      dismissInbox: (id) => set((state) => ({ inbox: state.inbox.filter((item) => item !== id) })),
      addAlarm: (alarm) => set((state) => ({ alarms: [...state.alarms, alarm] })),
      patchAlarm: (id, patch) =>
        set((state) => ({
          alarms: state.alarms.map((alarm) => (alarm.id === id ? { ...alarm, ...patch } : alarm)),
        })),
      deleteAlarm: (id) => set((state) => ({ alarms: state.alarms.filter((alarm) => alarm.id !== id) })),
      setPlace: (place) => set({ place }),
      setNotifyPrompt: (notifyPrompt) => set({ notifyPrompt }),
      dismissNotify: () => set({ notifyPrompt: false, notifyDismissed: true }),
    }),
    {
      name: "appnoteso",
      version: 1,
      skipHydration: true,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        view: state.view,
        notes: state.notes,
        alarms: state.alarms,
        place: state.place,
        draft: state.draft,
        draftReminder: state.draftReminder,
        inbox: state.inbox,
        notifyDismissed: state.notifyDismissed,
      }),
      merge: (persisted, current) => {
        const data =
          persisted && typeof persisted === "object" ? (persisted as Record<string, unknown>) : {};
        const view =
          data.view === "notas" || data.view === "alarme" || data.view === "tempo" ? data.view : current.view;
        return {
          ...current,
          view,
          notes: Array.isArray(data.notes)
            ? data.notes.map(cleanNote).filter((note): note is Note => note !== null)
            : [],
          alarms: Array.isArray(data.alarms)
            ? data.alarms.map(cleanAlarm).filter((alarm): alarm is Alarm => alarm !== null)
            : [],
          place: cleanPlace(data.place),
          draft: typeof data.draft === "string" ? data.draft.slice(0, NOTE_LIMIT) : "",
          draftReminder: typeof data.draftReminder === "string" ? data.draftReminder : "",
          inbox: Array.isArray(data.inbox)
            ? data.inbox.filter((item): item is string => typeof item === "string").slice(0, 5)
            : [],
          notifyDismissed: data.notifyDismissed === true,
        };
      },
    },
  ),
);

export function useHydrated(): boolean {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => {
    const unsub = useApp.persist.onFinishHydration(() => setHydrated(true));
    void useApp.persist.rehydrate();
    if (useApp.persist.hasHydrated()) setHydrated(true);
    return unsub;
  }, []);
  return hydrated;
}
