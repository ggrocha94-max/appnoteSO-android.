let ctx: AudioContext | null = null;
let timer = 0;
let playing = false;

export async function unlockAudio(): Promise<void> {
  if (typeof window === "undefined") return;
  ctx = ctx ?? new AudioContext();
  if (ctx.state === "suspended") await ctx.resume();
}

export function alarmAudible(): boolean {
  return ctx?.state === "running";
}

function tone(frequency: number, delay: number, sustain: number, peak: number) {
  if (!ctx || ctx.state !== "running") return;
  const start = ctx.currentTime + delay;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "sine";
  osc.frequency.value = frequency;
  gain.gain.setValueAtTime(0.0001, start);
  gain.gain.exponentialRampToValueAtTime(peak, start + 0.03);
  gain.gain.exponentialRampToValueAtTime(0.0001, start + sustain);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(start);
  osc.stop(start + sustain + 0.02);
}

function alarmChime() {
  tone(523.25, 0, 0.42, 0.14);
  tone(659.25, 0.16, 0.42, 0.12);
  tone(783.99, 0.32, 0.5, 0.1);
}

export function startAlarmTone() {
  try {
    void unlockAudio();
    if (playing) return;
    playing = true;
    alarmChime();
    timer = window.setInterval(alarmChime, 1400);
  } catch {
    playing = false;
  }
}

export function stopAlarmTone() {
  playing = false;
  window.clearInterval(timer);
  timer = 0;
}

export function playReminderChime() {
  try {
    void unlockAudio();
    tone(659.25, 0, 0.35, 0.08);
    tone(880, 0.14, 0.4, 0.06);
  } catch {
    // A blocked audio context just means the banner carries the reminder.
  }
}
