import { format, formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

export function cap(value: string): string {
  if (!value) return value;
  return value.charAt(0).toLocaleUpperCase("pt-BR") + value.slice(1);
}

export function clock(now: Date, withSeconds = false): string {
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  if (!withSeconds) return `${hh}:${mm}`;
  const ss = String(now.getSeconds()).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

export function longDate(now: Date): string {
  return cap(format(now, "EEEE, d 'de' MMMM", { locale: ptBR }));
}

export function ago(ts: number): string {
  return formatDistanceToNow(ts, { addSuffix: true, locale: ptBR });
}

export function reminderWhen(ts: number): string {
  return format(ts, "d 'de' MMM · HH:mm", { locale: ptBR });
}
