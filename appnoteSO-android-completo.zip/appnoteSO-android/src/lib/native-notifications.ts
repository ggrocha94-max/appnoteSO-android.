import { Capacitor } from "@capacitor/core";
import { LocalNotifications, type LocalNotificationSchema } from "@capacitor/local-notifications";
import type { Alarm, Note } from "@/lib/store";

const ALARM_ID_BASE = 100_000;
const NOTE_ID_BASE = 500_000;
const APP_GROUP = "appnoteso-scheduled";

function numericId(id: string, base: number): number {
  let hash = 0;
  for (let i = 0; i < id.length; i += 1) hash = (hash * 31 + id.charCodeAt(i)) >>> 0;
  return base + (hash % 100_000);
}

function nextDate(hour: number, minute: number, weekday?: number): Date {
  const now = new Date();
  const date = new Date(now);
  date.setSeconds(0, 0);
  date.setHours(hour, minute, 0, 0);
  if (weekday == null) {
    if (date.getTime() <= now.getTime()) date.setDate(date.getDate() + 1);
  } else {
    // JS weekday 0=Sunday; Local Notifications follows Calendar 1=Sunday.
    const delta = (weekday - now.getDay() + 7) % 7;
    date.setDate(now.getDate() + delta);
    date.setHours(hour, minute, 0, 0);
    if (date.getTime() <= now.getTime()) date.setDate(date.getDate() + 7);
  }
  return date;
}

export async function syncNativeSchedules(alarms: Alarm[], notes: Note[]): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  let permission = await LocalNotifications.checkPermissions();
  if (permission.display !== "granted") {
    permission = await LocalNotifications.requestPermissions();
  }
  if (permission.display !== "granted") return;

  const pending = await LocalNotifications.getPending();
  const owned = pending.notifications.filter((item) => item.group === APP_GROUP);
  if (owned.length) await LocalNotifications.cancel({ notifications: owned.map(({ id }) => ({ id })) });

  const notifications: LocalNotificationSchema[] = [];
  for (const alarm of alarms) {
    if (!alarm.enabled || (alarm.days.length === 0 && alarm.onceDone)) continue;
    const id = numericId(alarm.id, ALARM_ID_BASE);
    const title = alarm.label.trim() || "Alarme · appnoteSO";
    if (alarm.days.length === 0) {
      const when = nextDate(alarm.hour, alarm.minute);
      notifications.push({ id, title, body: "Está na hora.", schedule: { at: when }, group: APP_GROUP, extra: { kind: "alarm", alarmId: alarm.id } });
    } else {
      for (const weekday of alarm.days) {
        const weekdayId = id + weekday + 1;
        const when = nextDate(alarm.hour, alarm.minute, weekday);
        notifications.push({ id: weekdayId, title, body: "Está na hora.", schedule: { at: when, every: "week" }, group: APP_GROUP, extra: { kind: "alarm", alarmId: alarm.id, weekday } });
      }
    }
  }
  for (const note of notes) {
    if (!note.reminderAt || note.reminderFired || note.reminderAt <= Date.now()) continue;
    notifications.push({ id: numericId(note.id, NOTE_ID_BASE), title: "Lembrete · appnoteSO", body: note.body.trim().split("\n")[0]?.slice(0, 160) || "Uma nota sua", schedule: { at: new Date(note.reminderAt) }, group: APP_GROUP, extra: { kind: "note", noteId: note.id } });
  }
  if (notifications.length) await LocalNotifications.schedule({ notifications });
}
