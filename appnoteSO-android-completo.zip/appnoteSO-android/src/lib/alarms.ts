import type { Alarm } from "@/lib/store";
import { clock } from "@/lib/format";

export const WEEKDAYS = [
  { id: 0, short: "dom", long: "domingo" },
  { id: 1, short: "seg", long: "segunda" },
  { id: 2, short: "ter", long: "terça" },
  { id: 3, short: "qua", long: "quarta" },
  { id: 4, short: "qui", long: "quinta" },
  { id: 5, short: "sex", long: "sexta" },
  { id: 6, short: "sáb", long: "sábado" },
] as const;

const MONTHS = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

export function parseTime(value: string): { hour: number; minute: number } | null {
  const match = /^(\d{2}):(\d{2})$/.exec(value);
  if (!match) return null;
  const hour = Number(match[1]);
  const minute = Number(match[2]);
  if (hour > 23 || minute > 59) return null;
  return { hour, minute };
}

export function padTime(hour: number, minute: number): string {
  return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}

export function daysLabel(days: number[]): string {
  const sorted = [...new Set(days)].filter((day) => day >= 0 && day <= 6).sort((a, b) => a - b);
  if (sorted.length === 0) return "uma vez";
  if (sorted.length === 7) return "todo dia";
  const week = [1, 2, 3, 4, 5];
  if (sorted.length === 5 && week.every((day) => sorted.includes(day))) return "dias de semana";
  if (sorted.length === 2 && sorted[0] === 0 && sorted[1] === 6) return "fim de semana";
  return sorted.map((day) => WEEKDAYS[day]?.short ?? "").join(" · ");
}

function dayStamp(now: Date): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function sameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

/** Minute match within a 90s grace so a late tick still rings. */
export function dueMinuteKey(alarm: Alarm, now: Date): string | null {
  if (!alarm.enabled) return null;
  if (alarm.days.length === 0 && alarm.onceDone) return null;
  const target = new Date(now);
  target.setHours(alarm.hour, alarm.minute, 0, 0);
  const delta = now.getTime() - target.getTime();
  if (delta < 0 || delta >= 90_000) return null;
  if (alarm.days.length > 0 && !alarm.days.includes(now.getDay())) return null;
  return `${alarm.id}:${dayStamp(now)}`;
}

export function nextRing(alarm: Alarm, now: Date): Date | null {
  if (!alarm.enabled) return null;
  if (alarm.snoozeUntil != null && alarm.snoozeUntil > now.getTime()) {
    return new Date(alarm.snoozeUntil);
  }
  if (alarm.days.length === 0 && alarm.onceDone) return null;
  const horizon = alarm.days.length === 0 ? 2 : 8;
  for (let offset = 0; offset < horizon; offset += 1) {
    const when = new Date(now);
    when.setDate(now.getDate() + offset);
    when.setHours(alarm.hour, alarm.minute, 0, 0);
    if (when.getTime() <= now.getTime()) continue;
    if (alarm.days.length === 0 || alarm.days.includes(when.getDay())) return when;
  }
  return null;
}

export function soonest(alarms: Alarm[], now: Date): { alarm: Alarm; when: Date } | null {
  let best: { alarm: Alarm; when: Date } | null = null;
  for (const alarm of alarms) {
    const when = nextRing(alarm, now);
    if (!when) continue;
    if (!best || when.getTime() < best.when.getTime()) best = { alarm, when };
  }
  return best;
}

export function formatWhen(when: Date, now: Date): string {
  const hm = clock(when);
  if (sameDay(when, now)) return `hoje às ${hm}`;
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  if (sameDay(when, tomorrow)) return `amanhã às ${hm}`;
  return `${WEEKDAYS[when.getDay()]?.short ?? ""} ${when.getDate()} ${MONTHS[when.getMonth()]} às ${hm}`;
}
