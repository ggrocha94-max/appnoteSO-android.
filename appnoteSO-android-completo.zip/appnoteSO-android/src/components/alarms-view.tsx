import { useState } from "react";
import { Trash2 } from "lucide-react";
import { clock } from "@/lib/format";
import { daysLabel, formatWhen, padTime, parseTime, soonest, WEEKDAYS } from "@/lib/alarms";
import { uid, useApp, type Alarm } from "@/lib/store";
import { useNow } from "@/lib/use-now";

const field = "w-full rounded-2xl border border-line bg-surface-2 px-4 py-3 text-fg outline-none focus:border-accent";

function nudgeNotify() {
  if (typeof Notification === "undefined") return;
  if (Notification.permission !== "default") return;
  const { notifyDismissed, setNotifyPrompt } = useApp.getState();
  if (notifyDismissed) return;
  setNotifyPrompt(true);
}

export function AlarmsView() {
  const now = useNow();
  const alarms = useApp((state) => state.alarms);
  const addAlarm = useApp((state) => state.addAlarm);
  const [time, setTime] = useState("07:00");
  const [label, setLabel] = useState("");
  const [days, setDays] = useState<number[]>([0, 1, 2, 3, 4, 5, 6]);
  const [error, setError] = useState<string | null>(null);

  const ordered = [...alarms].sort((a, b) => a.hour * 60 + a.minute - (b.hour * 60 + b.minute));
  const next = now ? soonest(alarms, now) : null;
  const snoozing = next != null && next.alarm.snoozeUntil === next.when.getTime();

  function createAlarm() {
    if (alarms.length >= 24) {
      setError("Apaga um alarme antes de criar outro.");
      return;
    }
    const parsed = parseTime(time);
    if (!parsed) {
      setError("Escolhe um horário.");
      return;
    }
    addAlarm({
      id: uid(),
      label: label.trim(),
      hour: parsed.hour,
      minute: parsed.minute,
      enabled: true,
      days: [...days].sort((a, b) => a - b),
      lastFiredKey: null,
      snoozeUntil: null,
      onceDone: false,
    });
    setLabel("");
    setError(null);
    nudgeNotify();
  }

  return (
    <section className="max-w-md">
      <h1 className="sr-only">Alarme</h1>
      <div className="flex items-baseline gap-2">
        <p className="font-display text-6xl font-semibold tabular-nums text-fg">{now ? clock(now) : "--:--"}</p>
        <p className="font-display text-2xl font-semibold tabular-nums text-muted">
          {now ? String(now.getSeconds()).padStart(2, "0") : ""}
        </p>
      </div>
      <p className="mt-2 text-sm text-muted">
        {next && now
          ? `Próximo: ${formatWhen(next.when, now)}${snoozing ? " · soneca" : ""}${next.alarm.label ? ` · ${next.alarm.label}` : ""}`
          : "Nenhum alarme armado."}
      </p>
      <p className="mt-1 text-sm text-muted">No Android, os avisos são agendados como notificações. Permita as notificações para receber os alertas.</p>

      <form
        className="mt-8 flex flex-col gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          createAlarm();
        }}
      >
        <div>
          <label htmlFor="horario" className="mb-1 block text-sm text-muted">
            Horário
          </label>
          <input
            id="horario"
            type="time"
            step={60}
            required
            value={time}
            onChange={(event) => setTime(event.target.value)}
            className={`${field} font-display text-4xl font-semibold tabular-nums`}
          />
        </div>
        <div>
          <label htmlFor="nome-alarme" className="mb-1 block text-sm text-muted">
            Nome
          </label>
          <input
            id="nome-alarme"
            type="text"
            maxLength={80}
            value={label}
            placeholder="acordar, remédio, água…"
            onChange={(event) => setLabel(event.target.value)}
            className={field}
          />
        </div>
        <div>
          <p className="mb-2 text-sm text-muted">Repete</p>
          <div className="grid grid-cols-7 gap-1">
            {WEEKDAYS.map((day) => {
              const on = days.includes(day.id);
              return (
                <button
                  key={day.id}
                  type="button"
                  aria-pressed={on}
                  aria-label={day.long}
                  className={`h-11 rounded-full text-xs font-semibold ${on ? "bg-accent text-accent-ink" : "bg-surface-2 text-muted"}`}
                  onClick={() =>
                    setDays((current) =>
                      current.includes(day.id) ? current.filter((item) => item !== day.id) : [...current, day.id],
                    )
                  }
                >
                  {day.short}
                </button>
              );
            })}
          </div>
          <p className="mt-2 text-sm text-muted">
            {days.length === 0 ? "Toca uma vez e desliga." : "Repete nos dias marcados."}
          </p>
        </div>
        {error && <p className="text-sm text-accent">{error}</p>}
        <button
          type="submit"
          className="inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink"
        >
          Criar alarme
        </button>
      </form>

      {ordered.length > 0 && (
        <ul className="mt-8 flex flex-col gap-3">
          {ordered.map((alarm) => (
            <li key={alarm.id}>
              <AlarmRow alarm={alarm} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function AlarmRow({ alarm }: { alarm: Alarm }) {
  const patchAlarm = useApp((state) => state.patchAlarm);
  const deleteAlarm = useApp((state) => state.deleteAlarm);
  const [confirming, setConfirming] = useState(false);
  const time = padTime(alarm.hour, alarm.minute);

  return (
    <article className="rounded-2xl bg-surface px-4 py-3">
      <div className="flex items-center justify-between gap-3">
        <div className={`min-w-0 ${alarm.enabled ? "" : "opacity-50"}`}>
          <p className="font-display text-3xl font-semibold tabular-nums text-fg">{time}</p>
          <p className="truncate text-sm text-fg">{alarm.label || "Alarme"}</p>
          <p className="text-sm text-muted">{daysLabel(alarm.days)}</p>
        </div>
        {confirming ? (
          <div className="flex shrink-0 flex-col items-end">
            <button
              type="button"
              className="inline-flex h-11 items-center text-sm font-semibold text-accent"
              onClick={() => deleteAlarm(alarm.id)}
            >
              Apagar
            </button>
            <button
              type="button"
              className="inline-flex h-11 items-center text-sm text-muted"
              onClick={() => setConfirming(false)}
            >
              Cancelar
            </button>
          </div>
        ) : (
          <div className="flex shrink-0 items-center">
            <button
              type="button"
              role="switch"
              aria-checked={alarm.enabled}
              aria-label={`${time} ${alarm.enabled ? "ligado" : "desligado"}`}
              className="grid h-11 w-14 place-items-center"
              onClick={() =>
                patchAlarm(alarm.id, alarm.enabled ? { enabled: false, snoozeUntil: null } : { enabled: true })
              }
            >
              <span className={`relative h-7 w-12 rounded-full ${alarm.enabled ? "bg-accent" : "bg-line"}`}>
                <span
                  className={`absolute top-0.5 left-0.5 size-6 rounded-full bg-paper transition-transform motion-reduce:transition-none ${alarm.enabled ? "translate-x-5" : ""}`}
                />
              </span>
            </button>
            <button
              type="button"
              aria-label={`Apagar alarme ${time}`}
              className="grid size-11 place-items-center text-muted"
              onClick={() => setConfirming(true)}
            >
              <Trash2 className="size-4" aria-hidden />
            </button>
          </div>
        )}
      </div>
    </article>
  );
}
