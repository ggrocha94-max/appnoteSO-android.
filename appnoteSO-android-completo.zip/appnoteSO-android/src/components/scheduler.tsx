import { useEffect, useRef, useState } from "react";
import { dueMinuteKey } from "@/lib/alarms";
import { clock } from "@/lib/format";
import { useApp, type Alarm } from "@/lib/store";
import { alarmAudible, playReminderChime, startAlarmTone, stopAlarmTone, unlockAudio } from "@/lib/tone";
import { useNow } from "@/lib/use-now";

type Ring = {
  alarmId: string;
  key: string;
  label: string;
  once: boolean;
};

const seen = new Set<string>();
const GRACE_MS = 90_000;

function claim(key: string, lastFiredKey: string | null): boolean {
  if (lastFiredKey === key || seen.has(key)) return false;
  seen.add(key);
  return true;
}

function notify(title: string, body: string) {
  if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
  try {
    new Notification(title, { body });
  } catch {
    // Some browsers reject Notification outside a user gesture.
  }
}

function pickAlarm(alarm: Alarm, now: Date, patchAlarm: (id: string, patch: Partial<Alarm>) => void): string | null {
  if (!alarm.enabled) return null;
  if (alarm.snoozeUntil != null) {
    const delta = now.getTime() - alarm.snoozeUntil;
    if (delta < 0) return null;
    if (delta < GRACE_MS) {
      const key = `snooze:${alarm.id}:${alarm.snoozeUntil}`;
      return claim(key, alarm.lastFiredKey) ? key : null;
    }
    patchAlarm(alarm.id, { snoozeUntil: null });
  }
  const minute = dueMinuteKey(alarm, now);
  if (minute && claim(minute, alarm.lastFiredKey)) return minute;
  return null;
}

export function Scheduler() {
  const alarms = useApp((state) => state.alarms);
  const notes = useApp((state) => state.notes);
  const inbox = useApp((state) => state.inbox);
  const notifyPrompt = useApp((state) => state.notifyPrompt);
  const dismissNotify = useApp((state) => state.dismissNotify);
  const dismissInbox = useApp((state) => state.dismissInbox);
  const ringRef = useRef<Ring | null>(null);
  const [ring, setRing] = useState<Ring | null>(null);
  const ringNow = useRef(ring);
  ringNow.current = ring;

  useEffect(() => {
    const unlock = () => {
      void unlockAudio();
    };
    window.addEventListener("pointerdown", unlock, { once: true });
    return () => window.removeEventListener("pointerdown", unlock);
  }, []);

  useEffect(() => {
    let alive = true;
    const tick = () => {
      if (!alive) return;
      const state = useApp.getState();
      const now = new Date();
      if (!ringRef.current) {
        for (const alarm of state.alarms) {
          const key = pickAlarm(alarm, now, state.patchAlarm);
          if (!key) continue;
          const next: Ring = {
            alarmId: alarm.id,
            key,
            label: alarm.label,
            once: alarm.days.length === 0,
          };
          ringRef.current = next;
          setRing(next);
          startAlarmTone();
          if (document.visibilityState === "hidden") notify("Alarme", alarm.label || "Está na hora.");
          break;
        }
      }
      for (const note of state.notes) {
        if (!note.reminderAt || note.reminderFired || note.reminderAt > Date.now()) continue;
        state.markReminderFired(note.id);
        state.pushInbox(note.id);
        const text = note.body.trim().split("\n")[0]?.slice(0, 160) || "Uma nota sua";
        if (document.visibilityState === "hidden") notify("Lembrete", text);
        else if (!ringRef.current) playReminderChime();
      }
    };
    tick();
    const id = window.setInterval(tick, 1000);
    if (ringRef.current) startAlarmTone();
    return () => {
      alive = false;
      window.clearInterval(id);
      stopAlarmTone();
    };
  }, []);

  useEffect(() => {
    if (!ring) return;
    if (!alarms.some((alarm) => alarm.id === ring.alarmId)) {
      stopAlarmTone();
      ringRef.current = null;
      setRing(null);
    }
  }, [alarms, ring]);

  const openNotes = inbox
    .map((id) => notes.find((note) => note.id === id))
    .filter((note): note is NonNullable<typeof note> => note != null);

  useEffect(() => {
    for (const id of inbox) {
      if (!notes.some((note) => note.id === id)) dismissInbox(id);
    }
  }, [inbox, notes, dismissInbox]);

  function closeRing(snoozeMinutes: number | null) {
    const current = ringNow.current ?? ringRef.current;
    if (!current) return;
    stopAlarmTone();
    const patch =
      snoozeMinutes == null
        ? {
            lastFiredKey: current.key,
            snoozeUntil: null,
            ...(current.once ? { enabled: false, onceDone: true } : {}),
          }
        : {
            lastFiredKey: current.key,
            snoozeUntil: Date.now() + snoozeMinutes * 60_000,
            ...(current.once ? { onceDone: true } : {}),
          };
    useApp.getState().patchAlarm(current.alarmId, patch);
    seen.add(current.key);
    ringRef.current = null;
    ringNow.current = null;
    setRing(null);
  }

  return (
    <>
      {openNotes.length > 0 && (
        <div aria-live="polite" className="fixed inset-x-4 top-4 z-40 mx-auto flex max-w-md flex-col gap-2">
          {openNotes.map((note) => (
            <div key={note.id} className="sheet rounded-2xl px-5 py-4 pl-7">
              <p className="text-sm font-semibold text-accent-deep">Lembrete</p>
              <p className="mt-1 line-clamp-3 text-base">{note.body.trim() || "Uma nota sua"}</p>
              <button
                type="button"
                className="mt-3 h-11 text-sm font-semibold text-accent-deep"
                onClick={() => dismissInbox(note.id)}
              >
                Fechar
              </button>
            </div>
          ))}
        </div>
      )}

      {notifyPrompt && !ring && (
        <div className="fixed inset-x-4 bottom-24 z-40 mx-auto max-w-md rounded-2xl bg-surface p-4 md:bottom-6">
          <p className="font-display text-lg font-semibold text-fg">Avisos</p>
          <p className="mt-1 text-sm text-muted">
            Com o app aberto, o alarme toca aqui. Se permitir, o celular também avisa com a aba em segundo plano.
          </p>
          <div className="mt-3 flex gap-2">
            <button
              type="button"
              className="inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink"
              onClick={() => {
                void Notification.requestPermission().finally(() => dismissNotify());
              }}
            >
              Permitir avisos
            </button>
            <button
              type="button"
              className="inline-flex h-11 items-center justify-center rounded-full px-4 text-sm font-semibold text-muted"
              onClick={dismissNotify}
            >
              Agora não
            </button>
          </div>
        </div>
      )}

      {ring && <Ringer ring={ring} onSnooze={(minutes) => closeRing(minutes)} onStop={() => closeRing(null)} />}
    </>
  );
}

function Ringer({
  ring,
  onSnooze,
  onStop,
}: {
  ring: Ring;
  onSnooze: (minutes: number) => void;
  onStop: () => void;
}) {
  const now = useNow();
  const stopRef = useRef<HTMLButtonElement>(null);
  const onStopRef = useRef(onStop);
  const [silent, setSilent] = useState(false);
  onStopRef.current = onStop;

  useEffect(() => {
    const previous = document.title;
    const overflow = document.body.style.overflow;
    document.title = "Alarme · appnoteSO";
    document.body.style.overflow = "hidden";
    stopRef.current?.focus();
    const check = window.setTimeout(() => setSilent(!alarmAudible()), 250);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onStopRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.title = previous;
      document.body.style.overflow = overflow;
      window.clearTimeout(check);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="ring-title"
      className="fixed inset-0 z-50 flex flex-col items-center justify-center gap-6 bg-bg px-6 text-center"
    >
      <p id="ring-title" className="attn text-sm font-semibold text-accent">
        Alarme
      </p>
      <p className="font-display text-6xl font-semibold tabular-nums text-fg">{now ? clock(now) : "--:--"}</p>
      <p className="max-w-sm text-xl text-fg">{ring.label || "Está na hora."}</p>
      {silent && (
        <button
          type="button"
          className="h-11 text-sm font-semibold text-accent"
          onClick={() => {
            void unlockAudio().then(() => {
              stopAlarmTone();
              startAlarmTone();
              window.setTimeout(() => setSilent(!alarmAudible()), 200);
            });
          }}
        >
          Tocar o som
        </button>
      )}
      <div className="flex w-full max-w-sm flex-col gap-3">
        <button
          type="button"
          className="inline-flex h-12 items-center justify-center rounded-full bg-surface-2 text-sm font-semibold text-fg"
          onClick={() => onSnooze(5)}
        >
          Soneca 5 min
        </button>
        <button
          type="button"
          className="inline-flex h-12 items-center justify-center rounded-full bg-surface-2 text-sm font-semibold text-fg"
          onClick={() => onSnooze(10)}
        >
          Soneca 10 min
        </button>
        <button
          ref={stopRef}
          type="button"
          className="inline-flex h-12 items-center justify-center rounded-full bg-accent text-sm font-semibold text-accent-ink"
          onClick={onStop}
        >
          Desligar
        </button>
      </div>
    </div>
  );
}
