import { useState } from "react";
import { Bell, Pencil, Trash2 } from "lucide-react";
import { ago, reminderWhen } from "@/lib/format";
import { uid, useApp, type Note } from "@/lib/store";

const sheetField =
  "w-full rounded-2xl border border-ink/15 bg-ink/5 px-4 py-3 text-ink outline-none placeholder:text-ink-soft focus:border-accent-deep";

function nudgeNotify() {
  if (typeof Notification === "undefined") return;
  if (Notification.permission !== "default") return;
  const { notifyDismissed, setNotifyPrompt } = useApp.getState();
  if (notifyDismissed) return;
  setNotifyPrompt(true);
}

function parseReminder(value: string): { ok: true; at: number | null } | { ok: false } {
  if (!value) return { ok: true, at: null };
  const at = new Date(value).getTime();
  if (Number.isNaN(at)) return { ok: false };
  if (at < Date.now() - 30_000) return { ok: false };
  return { ok: true, at };
}

function toLocalInput(ts: number | null): string {
  if (!ts) return "";
  const date = new Date(ts);
  const pad = (part: number) => String(part).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function NotesView() {
  const draft = useApp((state) => state.draft);
  const draftReminder = useApp((state) => state.draftReminder);
  const setDraft = useApp((state) => state.setDraft);
  const setDraftReminder = useApp((state) => state.setDraftReminder);
  const clearDraft = useApp((state) => state.clearDraft);
  const addNote = useApp((state) => state.addNote);
  const notes = useApp((state) => state.notes);
  const [reminderOpen, setReminderOpen] = useState(() => draftReminder !== "");
  const [error, setError] = useState<string | null>(null);

  function save() {
    const body = draft.trim();
    if (!body) return;
    const parsed = parseReminder(draftReminder);
    if (!parsed.ok) {
      setError("Esse horário já passou.");
      return;
    }
    const now = Date.now();
    addNote({
      id: uid(),
      body,
      createdAt: now,
      updatedAt: now,
      reminderAt: parsed.at,
      reminderFired: false,
    });
    clearDraft();
    setReminderOpen(false);
    setError(null);
    if (parsed.at) nudgeNotify();
  }

  const ordered = [...notes].sort((a, b) => b.updatedAt - a.updatedAt);

  return (
    <section>
      <h1 className="sr-only">Notas</h1>
      <form
        className="sheet rise rounded-2xl py-5 pr-5 pl-7"
        onSubmit={(event) => {
          event.preventDefault();
          save();
        }}
      >
        <label htmlFor="nota" className="sr-only">
          Nota
        </label>
        <textarea
          id="nota"
          value={draft}
          maxLength={12000}
          placeholder="Escreve o que está pesando. Só neste aparelho."
          className={`${sheetField} min-h-36 text-lg leading-normal`}
          onChange={(event) => {
            setDraft(event.target.value);
            setError(null);
          }}
          onKeyDown={(event) => {
            if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
              event.preventDefault();
              save();
            }
          }}
        />
        {reminderOpen && (
          <div className="mt-3">
            <label htmlFor="lembrete" className="mb-1 block text-sm text-ink-soft">
              Quando avisar
            </label>
            <input
              id="lembrete"
              type="datetime-local"
              value={draftReminder}
              className={`${sheetField} min-h-11`}
              onChange={(event) => {
                setDraftReminder(event.target.value);
                setError(null);
              }}
            />
          </div>
        )}
        {error && <p className="mt-2 text-sm text-accent-deep">{error}</p>}
        <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            aria-pressed={reminderOpen}
            className="inline-flex h-11 items-center gap-2 text-sm font-semibold text-accent-deep"
            onClick={() => {
              if (reminderOpen) {
                setDraftReminder("");
                setError(null);
              }
              setReminderOpen((open) => !open);
            }}
          >
            <Bell className="size-4" aria-hidden />
            Lembrete
          </button>
          <div className="flex items-center gap-3">
            <span className="hidden text-xs text-ink-soft sm:inline">Ctrl+Enter guarda</span>
            <button
              type="submit"
              disabled={!draft.trim()}
              className="inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink disabled:opacity-40"
            >
              Guardar
            </button>
          </div>
        </div>
      </form>

      {ordered.length === 0 ? (
        <p className="px-1 pt-6 text-base text-muted italic">Nada escrito ainda. Quando precisar, deixa aqui.</p>
      ) : (
        <ul className="mt-5 flex flex-col gap-4">
          {ordered.map((note) => (
            <li key={note.id}>
              <NoteCard note={note} />
            </li>
          ))}
        </ul>
      )}

      <p className="px-1 pt-8 text-xs text-muted">
        As notas ficam salvas neste aparelho. Se apagar os dados do app, elas serão removidas.
      </p>
    </section>
  );
}

function NoteCard({ note }: { note: Note }) {
  const updateNote = useApp((state) => state.updateNote);
  const deleteNote = useApp((state) => state.deleteNote);
  const [editing, setEditing] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [body, setBody] = useState(note.body);
  const [reminder, setReminder] = useState(toLocalInput(note.reminderAt));
  const [error, setError] = useState<string | null>(null);
  const long = note.body.length > 480 || note.body.split("\n").length > 8;

  function saveEdit() {
    const next = body.trim();
    if (!next) {
      setError("Escreve alguma coisa.");
      return;
    }
    const parsed = parseReminder(reminder);
    if (!parsed.ok) {
      setError("Esse horário já passou.");
      return;
    }
    const sameReminder = note.reminderAt === parsed.at;
    updateNote(note.id, {
      body: next,
      updatedAt: Date.now(),
      reminderAt: parsed.at,
      reminderFired: sameReminder ? note.reminderFired : false,
    });
    if (parsed.at && !sameReminder) nudgeNotify();
    setEditing(false);
    setError(null);
  }

  if (editing) {
    return (
      <form
        className="sheet rounded-2xl py-5 pr-5 pl-7"
        onSubmit={(event) => {
          event.preventDefault();
          saveEdit();
        }}
      >
        <label htmlFor={`edit-${note.id}`} className="sr-only">
          Editar nota
        </label>
        <textarea
          id={`edit-${note.id}`}
          value={body}
          maxLength={12000}
          className={`${sheetField} min-h-36 text-lg leading-normal`}
          onChange={(event) => {
            setBody(event.target.value);
            setError(null);
          }}
        />
        <label htmlFor={`edit-reminder-${note.id}`} className="mt-3 mb-1 block text-sm text-ink-soft">
          Quando avisar
        </label>
        <input
          id={`edit-reminder-${note.id}`}
          type="datetime-local"
          value={reminder}
          className={`${sheetField} min-h-11`}
          onChange={(event) => {
            setReminder(event.target.value);
            setError(null);
          }}
        />
        {error && <p className="mt-2 text-sm text-accent-deep">{error}</p>}
        <div className="mt-3 flex gap-2">
          <button
            type="submit"
            className="inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink"
          >
            Salvar
          </button>
          <button
            type="button"
            className="inline-flex h-11 items-center justify-center rounded-full px-4 text-sm font-semibold text-ink-soft"
            onClick={() => {
              setEditing(false);
              setBody(note.body);
              setReminder(toLocalInput(note.reminderAt));
              setError(null);
            }}
          >
            Cancelar
          </button>
        </div>
      </form>
    );
  }

  return (
    <article className="sheet rise rounded-2xl py-4 pr-3 pl-7">
      <div className="flex items-start justify-between gap-2">
        <time className="pt-2 text-sm text-ink-soft" dateTime={new Date(note.updatedAt).toISOString()}>
          {ago(note.updatedAt)}
        </time>
        <div className="flex">
          {confirming ? (
            <div className="flex items-center gap-1 pr-2">
              <button
                type="button"
                className="inline-flex h-11 items-center px-2 text-sm font-semibold text-accent-deep"
                onClick={() => deleteNote(note.id)}
              >
                Apagar
              </button>
              <button
                type="button"
                className="inline-flex h-11 items-center px-2 text-sm text-ink-soft"
                onClick={() => setConfirming(false)}
              >
                Cancelar
              </button>
            </div>
          ) : (
            <>
              <button
                type="button"
                aria-label="Editar nota"
                className="grid size-11 place-items-center text-ink-soft"
                onClick={() => {
                  setBody(note.body);
                  setReminder(toLocalInput(note.reminderAt));
                  setEditing(true);
                }}
              >
                <Pencil className="size-4" aria-hidden />
              </button>
              <button
                type="button"
                aria-label="Apagar nota"
                className="grid size-11 place-items-center text-ink-soft"
                onClick={() => setConfirming(true)}
              >
                <Trash2 className="size-4" aria-hidden />
              </button>
            </>
          )}
        </div>
      </div>
      <p
        className={`text-lg leading-normal break-words whitespace-pre-wrap ${long && !expanded ? "max-h-40 overflow-hidden" : ""}`}
      >
        {note.body}
      </p>
      {long && (
        <button
          type="button"
          className="mt-2 text-sm font-semibold text-accent-deep"
          onClick={() => setExpanded((open) => !open)}
        >
          {expanded ? "Recolher" : "Ler tudo"}
        </button>
      )}
      {note.reminderAt && (
        <p className="mt-3 flex items-center gap-2 text-sm text-accent-deep">
          <Bell className="size-4 shrink-0" aria-hidden />
          {note.reminderFired ? `avisado · ${reminderWhen(note.reminderAt)}` : reminderWhen(note.reminderAt)}
        </p>
      )}
    </article>
  );
}
