import { useEffect, useState } from "react";
import {
  Cloud,
  CloudDrizzle,
  CloudFog,
  CloudLightning,
  CloudMoon,
  CloudRain,
  CloudSnow,
  CloudSun,
  LocateFixed,
  Moon,
  Sun,
  type LucideIcon,
} from "lucide-react";
import { clock } from "@/lib/format";
import { useApp, type Place } from "@/lib/store";
import {
  describeWeather,
  loadForecast,
  peekForecast,
  placeFromCoords,
  searchCities,
  type Forecast,
  type SkyIcon,
} from "@/lib/weather";

const ICONS: Record<SkyIcon, LucideIcon> = {
  sun: Sun,
  moon: Moon,
  "cloud-sun": CloudSun,
  "cloud-moon": CloudMoon,
  cloud: Cloud,
  fog: CloudFog,
  drizzle: CloudDrizzle,
  rain: CloudRain,
  snow: CloudSnow,
  storm: CloudLightning,
};

const field = "w-full min-h-11 rounded-2xl border border-line bg-surface-2 px-4 py-3 text-fg outline-none focus:border-accent";

function placeDetail(place: Place): string {
  return [place.admin1, place.country].filter((part) => part && part !== place.name).join(" · ");
}

function SkyGlyph({ code, isDay, className }: { code: number; isDay: boolean; className?: string }) {
  const { icon } = describeWeather(code, isDay);
  const Icon = ICONS[icon];
  return <Icon className={className} aria-hidden />;
}

export function WeatherView() {
  const place = useApp((state) => state.place);
  const setPlace = useApp((state) => state.setPlace);
  const [editing, setEditing] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Place[]>([]);
  const [searching, setSearching] = useState(false);
  const [settledQuery, setSettledQuery] = useState("");
  const [searchError, setSearchError] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);
  const [locError, setLocError] = useState<string | null>(null);
  const [forecast, setForecast] = useState<Forecast | null>(null);
  const [loading, setLoading] = useState(false);
  const [forecastError, setForecastError] = useState<string | null>(null);
  const [refreshToken, setRefreshToken] = useState(0);

  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setResults([]);
      setSearching(false);
      setSettledQuery("");
      return;
    }
    const ctrl = new AbortController();
    const timeout = window.setTimeout(() => {
      setSearching(true);
      searchCities(q, ctrl.signal)
        .then((found) => {
          if (ctrl.signal.aborted) return;
          setResults(found);
          setSearchError(null);
          setSettledQuery(q);
        })
        .catch((error: unknown) => {
          if (error instanceof DOMException && error.name === "AbortError") return;
          if (!ctrl.signal.aborted) setSearchError("Não deu pra buscar agora.");
        })
        .finally(() => {
          if (!ctrl.signal.aborted) setSearching(false);
        });
    }, 300);
    return () => {
      ctrl.abort();
      window.clearTimeout(timeout);
    };
  }, [query]);

  useEffect(() => {
    if (!place) return;
    const ctrl = new AbortController();
    const cached = refreshToken === 0 ? peekForecast(place) : null;
    if (cached) setForecast(cached);
    setLoading(!cached);
    setForecastError(null);
    loadForecast(place, ctrl.signal, refreshToken > 0)
      .then((data) => {
        if (ctrl.signal.aborted) return;
        setForecast(data);
        setForecastError(null);
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        if (!ctrl.signal.aborted) setForecastError("Não consegui buscar a previsão.");
      })
      .finally(() => {
        if (!ctrl.signal.aborted) setLoading(false);
      });
    return () => ctrl.abort();
  }, [place, refreshToken]);

  function choose(next: Place) {
    setPlace(next);
    setEditing(false);
    setQuery("");
    setResults([]);
    setLocError(null);
    setRefreshToken(0);
  }

  function locate() {
    if (!navigator.geolocation) {
      setLocError("Este navegador não entrega localização.");
      return;
    }
    setLocating(true);
    setLocError(null);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        void placeFromCoords(position.coords.latitude, position.coords.longitude)
          .then((next) => {
            choose(next);
          })
          .catch(() => {
            setLocError("Não consegui usar sua localização. Busca a cidade pelo nome.");
          })
          .finally(() => setLocating(false));
      },
      () => {
        setLocating(false);
        setLocError("Não consegui usar sua localização. Busca a cidade pelo nome.");
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 600_000 },
    );
  }

  const showSearch = !place || editing;
  const emptySearch = settledQuery.length >= 2 && settledQuery === query.trim() && !searching && results.length === 0;
  const browserOffset = -new Date().getTimezoneOffset() * 60;
  const otherZone = forecast != null && forecast.offsetSeconds !== browserOffset;

  return (
    <section className="max-w-xl">
      <h1 className="sr-only">Tempo</h1>
      {showSearch && (
        <div className="flex flex-col gap-3">
          <label htmlFor="cidade" className="text-sm text-muted">
            Cidade
          </label>
          <input
            id="cidade"
            type="search"
            value={query}
            placeholder="Buscar cidade"
            autoComplete="off"
            className={field}
            onChange={(event) => setQuery(event.target.value)}
          />
          {searching && <p className="text-sm text-muted">Buscando…</p>}
          {searchError && <p className="text-sm text-accent">{searchError}</p>}
          {emptySearch && !searchError && <p className="text-sm text-muted">Nenhuma cidade com esse nome.</p>}
          {results.length > 0 && (
            <ul className="overflow-hidden rounded-2xl border border-line bg-surface">
              {results.map((city) => (
                <li key={`${city.id}-${city.latitude}`}>
                  <button
                    type="button"
                    className="flex min-h-11 w-full flex-col items-start justify-center px-4 py-2 text-left hover:bg-surface-2"
                    onClick={() => choose(city)}
                  >
                    <span className="text-fg">{city.name}</span>
                    {placeDetail(city) && <span className="text-sm text-muted">{placeDetail(city)}</span>}
                  </button>
                </li>
              ))}
            </ul>
          )}
          <button
            type="button"
            disabled={locating}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-surface-2 px-5 text-sm font-semibold text-fg disabled:opacity-40"
            onClick={locate}
          >
            <LocateFixed className="size-4" aria-hidden />
            {locating ? "Buscando você…" : "Usar minha localização"}
          </button>
          {locError && <p className="text-sm text-accent">{locError}</p>}
          {place && (
            <button
              type="button"
              className="h-11 self-start text-sm font-semibold text-muted"
              onClick={() => setEditing(false)}
            >
              Cancelar
            </button>
          )}
        </div>
      )}

      {place && !showSearch && (
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="font-display text-3xl font-semibold text-fg">{place.name}</h2>
            {placeDetail(place) && <p className="text-sm text-muted">{placeDetail(place)}</p>}
          </div>
          <button type="button" className="h-11 shrink-0 text-sm font-semibold text-accent" onClick={() => setEditing(true)}>
            Trocar
          </button>
        </div>
      )}

      {place && loading && !forecast && <p className="mt-8 text-muted">Buscando a previsão…</p>}
      {place && forecastError && !forecast && (
        <div className="mt-8">
          <p className="text-muted">{forecastError}</p>
          <button
            type="button"
            className="mt-3 inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink"
            onClick={() => setRefreshToken((token) => token + 1)}
          >
            Tentar de novo
          </button>
        </div>
      )}

      {forecast && place && !showSearch && (
        <div className="mt-6">
          <div className="flex items-end justify-between gap-4">
            <p className="font-display text-7xl font-semibold tabular-nums leading-none text-fg">
              {forecast.current.temp}°
            </p>
            <SkyGlyph code={forecast.current.code} isDay={forecast.current.isDay} className="mb-1 size-10 text-accent" />
          </div>
          <p className="mt-3 text-lg text-fg">{describeWeather(forecast.current.code, forecast.current.isDay).label}</p>
          <p className="mt-1 text-sm text-muted">
            sensação {forecast.current.apparent}° · umidade {forecast.current.humidity}% · vento {forecast.current.wind}{" "}
            km/h
          </p>
          <p className="mt-1 text-xs text-muted">
            atualizado às {clock(new Date(forecast.fetchedAt))}
            {forecastError ? " · sem conexão, esta é a última previsão" : ""}
          </p>

          {forecast.hours.length > 0 && (
            <div className="mt-8">
              <div className="mb-3 flex items-baseline justify-between gap-3">
                <h3 className="font-display text-xl font-semibold text-fg">Próximas horas</h3>
                {otherZone && <p className="text-xs text-muted">horário da cidade</p>}
              </div>
              <div className="scroll-x -mx-4 flex gap-2 px-4">
                {forecast.hours.map((hour, index) => (
                  <div
                    key={`${hour.label}-${index}`}
                    className="flex w-16 shrink-0 flex-col items-center gap-1 rounded-2xl bg-surface py-3"
                  >
                    <span className="text-xs text-muted">{hour.label}</span>
                    <SkyGlyph code={hour.code} isDay={hour.isDay} className="size-5 text-fg" />
                    <span className="text-sm tabular-nums text-fg">{hour.temp}°</span>
                    {hour.pop >= 20 && <span className="text-xs tabular-nums text-accent">{hour.pop}%</span>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {forecast.days.length > 0 && (
            <div className="mt-8">
              <h3 className="font-display text-xl font-semibold text-fg">Próximos dias</h3>
              <ul className="mt-2">
                {forecast.days.map((day) => (
                  <li key={day.label} className="flex items-center gap-3 border-t border-line py-3">
                    <span className="w-20 text-sm text-muted">{day.label}</span>
                    <SkyGlyph code={day.code} isDay className="size-5 text-fg" />
                    {day.pop >= 20 && <span className="text-xs tabular-nums text-accent">{day.pop}%</span>}
                    <span className="ml-auto tabular-nums text-fg">{day.max}°</span>
                    <span className="w-10 text-right tabular-nums text-muted">{day.min}°</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <button
            type="button"
            className="mt-6 h-11 text-sm font-semibold text-accent"
            onClick={() => setRefreshToken((token) => token + 1)}
          >
            Atualizar
          </button>
        </div>
      )}

      {!place && !showSearch && <p className="mt-8 text-muted">Escolhe uma cidade pra ver o tempo.</p>}
    </section>
  );
}
