import { AlarmClock, CloudSun, NotebookPen, type LucideIcon } from "lucide-react";
import { clock, longDate } from "@/lib/format";
import { useApp, useHydrated, type ViewName } from "@/lib/store";
import { useNow } from "@/lib/use-now";
import { AlarmsView } from "@/components/alarms-view";
import { NotesView } from "@/components/notes-view";
import { Scheduler } from "@/components/scheduler";
import { WeatherView } from "@/components/weather-view";

const TABS: { id: ViewName; label: string; icon: LucideIcon }[] = [
  { id: "notas", label: "Notas", icon: NotebookPen },
  { id: "alarme", label: "Alarme", icon: AlarmClock },
  { id: "tempo", label: "Tempo", icon: CloudSun },
];

export function App() {
  const hydrated = useHydrated();
  const view = useApp((state) => state.view);

  return (
    <div className="min-h-dvh">
      <Header showNav={hydrated} />
      <main className="mx-auto w-full max-w-2xl px-4 pt-6 pb-28 md:pb-12">
        {!hydrated && <p className="text-muted">Abrindo o caderno…</p>}
        {hydrated && view === "notas" && <NotesView />}
        {hydrated && view === "alarme" && <AlarmsView />}
        {hydrated && view === "tempo" && <WeatherView />}
      </main>
      {hydrated && (
        <div className="dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 backdrop-blur md:hidden">
          <Nav variant="dock" />
        </div>
      )}
      {hydrated && <Scheduler />}
    </div>
  );
}

function Header({ showNav }: { showNav: boolean }) {
  const now = useNow();
  return (
    <header className="sticky top-0 z-20 border-b border-line bg-bg/90 px-4 py-4 backdrop-blur">
      <div className="mx-auto flex max-w-2xl items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="font-display text-2xl font-semibold leading-none tracking-tight text-fg">
            appnote<span className="text-accent">SO</span>
          </p>
          <p className="mt-1 min-h-5 text-sm text-muted">{now ? longDate(now) : "\u00a0"}</p>
        </div>
        <p className="shrink-0 font-display text-3xl font-semibold tabular-nums text-fg">
          {now ? clock(now) : "--:--"}
        </p>
      </div>
      {showNav && (
        <div className="mx-auto mt-4 hidden max-w-2xl md:block">
          <Nav variant="bar" />
        </div>
      )}
    </header>
  );
}

function Nav({ variant }: { variant: "dock" | "bar" }) {
  const view = useApp((state) => state.view);
  const setView = useApp((state) => state.setView);
  return (
    <nav
      aria-label="Seções"
      className={
        variant === "dock" ? "mx-auto grid max-w-2xl grid-cols-3" : "flex w-fit gap-1 rounded-full bg-surface p-1"
      }
    >
      {TABS.map(({ id, label, icon: Icon }) => {
        const active = view === id;
        const className =
          variant === "dock"
            ? `flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-semibold ${active ? "text-accent" : "text-muted"}`
            : `h-11 rounded-full px-4 text-sm font-semibold ${active ? "bg-accent text-accent-ink" : "text-muted"}`;
        return (
          <button
            key={id}
            type="button"
            aria-current={active ? "page" : undefined}
            onClick={() => setView(id)}
            className={className}
          >
            {variant === "dock" && <Icon className="size-5" aria-hidden />}
            {label}
          </button>
        );
      })}
    </nav>
  );
}
