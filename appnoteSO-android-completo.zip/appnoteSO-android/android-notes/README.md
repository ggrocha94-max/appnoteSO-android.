A pasta `android/` é gerada pelo Capacitor CLI depois que a versão web estática e offline estiver pronta:

```sh
npm install
npm run android:init
npm run android:sync
npm run android:build:debug
```

Veja `ANDROID-APK.md` antes de compilar. O projeto original usa TanStack Start/Nitro e precisa de uma saída de cliente estática em `www/`; não existe APK pré-compilado neste pacote.
