import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as AlarmClock, a as NotebookPen, c as Cloud, d as CloudRain, f as CloudMoon, g as Bell, h as CloudDrizzle, i as Pencil, l as CloudSun, m as CloudFog, n as Trash2, o as Moon, p as CloudLightning, r as Sun, s as LocateFixed, u as CloudSnow } from "../_libs/lucide-react.mjs";
import { n as formatDistanceToNow, r as format, t as ptBR } from "../_libs/date-fns.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BYJkXZSB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cap(value) {
	if (!value) return value;
	return value.charAt(0).toLocaleUpperCase("pt-BR") + value.slice(1);
}
function clock(now, withSeconds = false) {
	const hh = String(now.getHours()).padStart(2, "0");
	const mm = String(now.getMinutes()).padStart(2, "0");
	if (!withSeconds) return `${hh}:${mm}`;
	return `${hh}:${mm}:${String(now.getSeconds()).padStart(2, "0")}`;
}
function longDate(now) {
	return cap(format(now, "EEEE, d 'de' MMMM", { locale: ptBR }));
}
function ago(ts) {
	return formatDistanceToNow(ts, {
		addSuffix: true,
		locale: ptBR
	});
}
function reminderWhen(ts) {
	return format(ts, "d 'de' MMM · HH:mm", { locale: ptBR });
}
var NOTE_LIMIT = 12e3;
function cleanNote(value) {
	if (!value || typeof value !== "object") return null;
	const note = value;
	if (typeof note.id !== "string" || typeof note.body !== "string") return null;
	const createdAt = typeof note.createdAt === "number" ? note.createdAt : Date.now();
	return {
		id: note.id,
		body: note.body.slice(0, NOTE_LIMIT),
		createdAt,
		updatedAt: typeof note.updatedAt === "number" ? note.updatedAt : createdAt,
		reminderAt: typeof note.reminderAt === "number" ? note.reminderAt : null,
		reminderFired: note.reminderFired === true
	};
}
function cleanAlarm(value) {
	if (!value || typeof value !== "object") return null;
	const alarm = value;
	if (typeof alarm.id !== "string") return null;
	const hour = typeof alarm.hour === "number" ? alarm.hour : -1;
	const minute = typeof alarm.minute === "number" ? alarm.minute : -1;
	if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
	const days = Array.isArray(alarm.days) ? [...new Set(alarm.days.filter((day) => typeof day === "number" && day >= 0 && day <= 6))].sort((a, b) => a - b) : [];
	return {
		id: alarm.id,
		label: typeof alarm.label === "string" ? alarm.label.slice(0, 80) : "",
		hour,
		minute,
		enabled: alarm.enabled !== false,
		days,
		lastFiredKey: typeof alarm.lastFiredKey === "string" ? alarm.lastFiredKey : null,
		snoozeUntil: typeof alarm.snoozeUntil === "number" ? alarm.snoozeUntil : null,
		onceDone: alarm.onceDone === true
	};
}
function cleanPlace(value) {
	if (!value || typeof value !== "object") return null;
	const place = value;
	if (typeof place.latitude !== "number" || typeof place.longitude !== "number") return null;
	if (!Number.isFinite(place.latitude) || !Number.isFinite(place.longitude)) return null;
	return {
		id: typeof place.id === "number" ? place.id : Math.round(place.latitude * 1e3),
		name: typeof place.name === "string" && place.name ? place.name : "Cidade",
		admin1: typeof place.admin1 === "string" ? place.admin1 : "",
		country: typeof place.country === "string" ? place.country : "",
		latitude: place.latitude,
		longitude: place.longitude
	};
}
function uid() {
	return crypto.randomUUID();
}
var useApp = create()(persist((set) => ({
	view: "notas",
	notes: [],
	alarms: [],
	place: null,
	draft: "",
	draftReminder: "",
	inbox: [],
	notifyDismissed: false,
	notifyPrompt: false,
	setView: (view) => set({ view }),
	setDraft: (draft) => set({ draft: draft.slice(0, NOTE_LIMIT) }),
	setDraftReminder: (draftReminder) => set({ draftReminder }),
	clearDraft: () => set({
		draft: "",
		draftReminder: ""
	}),
	addNote: (note) => set((state) => ({ notes: [note, ...state.notes] })),
	updateNote: (id, patch) => set((state) => ({ notes: state.notes.map((note) => note.id === id ? {
		...note,
		...patch
	} : note) })),
	deleteNote: (id) => set((state) => ({
		notes: state.notes.filter((note) => note.id !== id),
		inbox: state.inbox.filter((item) => item !== id)
	})),
	markReminderFired: (id) => set((state) => ({ notes: state.notes.map((note) => note.id === id ? {
		...note,
		reminderFired: true
	} : note) })),
	pushInbox: (id) => set((state) => state.inbox.includes(id) ? state : { inbox: [id, ...state.inbox].slice(0, 5) }),
	dismissInbox: (id) => set((state) => ({ inbox: state.inbox.filter((item) => item !== id) })),
	addAlarm: (alarm) => set((state) => ({ alarms: [...state.alarms, alarm] })),
	patchAlarm: (id, patch) => set((state) => ({ alarms: state.alarms.map((alarm) => alarm.id === id ? {
		...alarm,
		...patch
	} : alarm) })),
	deleteAlarm: (id) => set((state) => ({ alarms: state.alarms.filter((alarm) => alarm.id !== id) })),
	setPlace: (place) => set({ place }),
	setNotifyPrompt: (notifyPrompt) => set({ notifyPrompt }),
	dismissNotify: () => set({
		notifyPrompt: false,
		notifyDismissed: true
	})
}), {
	name: "appnoteso",
	version: 1,
	skipHydration: true,
	storage: createJSONStorage(() => localStorage),
	partialize: (state) => ({
		view: state.view,
		notes: state.notes,
		alarms: state.alarms,
		place: state.place,
		draft: state.draft,
		draftReminder: state.draftReminder,
		inbox: state.inbox,
		notifyDismissed: state.notifyDismissed
	}),
	merge: (persisted, current) => {
		const data = persisted && typeof persisted === "object" ? persisted : {};
		const view = data.view === "notas" || data.view === "alarme" || data.view === "tempo" ? data.view : current.view;
		return {
			...current,
			view,
			notes: Array.isArray(data.notes) ? data.notes.map(cleanNote).filter((note) => note !== null) : [],
			alarms: Array.isArray(data.alarms) ? data.alarms.map(cleanAlarm).filter((alarm) => alarm !== null) : [],
			place: cleanPlace(data.place),
			draft: typeof data.draft === "string" ? data.draft.slice(0, NOTE_LIMIT) : "",
			draftReminder: typeof data.draftReminder === "string" ? data.draftReminder : "",
			inbox: Array.isArray(data.inbox) ? data.inbox.filter((item) => typeof item === "string").slice(0, 5) : [],
			notifyDismissed: data.notifyDismissed === true
		};
	}
}));
function useHydrated() {
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const unsub = useApp.persist.onFinishHydration(() => setHydrated(true));
		useApp.persist.rehydrate();
		if (useApp.persist.hasHydrated()) setHydrated(true);
		return unsub;
	}, []);
	return hydrated;
}
function useNow(intervalMs = 1e3) {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), intervalMs);
		return () => window.clearInterval(id);
	}, [intervalMs]);
	return now;
}
var WEEKDAYS = [
	{
		id: 0,
		short: "dom",
		long: "domingo"
	},
	{
		id: 1,
		short: "seg",
		long: "segunda"
	},
	{
		id: 2,
		short: "ter",
		long: "terça"
	},
	{
		id: 3,
		short: "qua",
		long: "quarta"
	},
	{
		id: 4,
		short: "qui",
		long: "quinta"
	},
	{
		id: 5,
		short: "sex",
		long: "sexta"
	},
	{
		id: 6,
		short: "sáb",
		long: "sábado"
	}
];
var MONTHS = [
	"jan",
	"fev",
	"mar",
	"abr",
	"mai",
	"jun",
	"jul",
	"ago",
	"set",
	"out",
	"nov",
	"dez"
];
function parseTime(value) {
	const match = /^(\d{2}):(\d{2})$/.exec(value);
	if (!match) return null;
	const hour = Number(match[1]);
	const minute = Number(match[2]);
	if (hour > 23 || minute > 59) return null;
	return {
		hour,
		minute
	};
}
function padTime(hour, minute) {
	return `${String(hour).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
}
function daysLabel(days) {
	const sorted = [...new Set(days)].filter((day) => day >= 0 && day <= 6).sort((a, b) => a - b);
	if (sorted.length === 0) return "uma vez";
	if (sorted.length === 7) return "todo dia";
	if (sorted.length === 5 && [
		1,
		2,
		3,
		4,
		5
	].every((day) => sorted.includes(day))) return "dias de semana";
	if (sorted.length === 2 && sorted[0] === 0 && sorted[1] === 6) return "fim de semana";
	return sorted.map((day) => WEEKDAYS[day]?.short ?? "").join(" · ");
}
function dayStamp(now) {
	return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
function sameDay(a, b) {
	return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}
/** Minute match within a 90s grace so a late tick still rings. */
function dueMinuteKey(alarm, now) {
	if (!alarm.enabled) return null;
	if (alarm.days.length === 0 && alarm.onceDone) return null;
	const target = new Date(now);
	target.setHours(alarm.hour, alarm.minute, 0, 0);
	const delta = now.getTime() - target.getTime();
	if (delta < 0 || delta >= 9e4) return null;
	if (alarm.days.length > 0 && !alarm.days.includes(now.getDay())) return null;
	return `${alarm.id}:${dayStamp(now)}`;
}
function nextRing(alarm, now) {
	if (!alarm.enabled) return null;
	if (alarm.snoozeUntil != null && alarm.snoozeUntil > now.getTime()) return new Date(alarm.snoozeUntil);
	if (alarm.days.length === 0 && alarm.onceDone) return null;
	const horizon = alarm.days.length === 0 ? 2 : 8;
	for (let offset = 0; offset < horizon; offset += 1) {
		const when = new Date(now);
		when.setDate(now.getDate() + offset);
		when.setHours(alarm.hour, alarm.minute, 0, 0);
		if (when.getTime() <= now.getTime()) continue;
		if (alarm.days.length === 0 || alarm.days.includes(when.getDay())) return when;
	}
	return null;
}
function soonest(alarms, now) {
	let best = null;
	for (const alarm of alarms) {
		const when = nextRing(alarm, now);
		if (!when) continue;
		if (!best || when.getTime() < best.when.getTime()) best = {
			alarm,
			when
		};
	}
	return best;
}
function formatWhen(when, now) {
	const hm = clock(when);
	if (sameDay(when, now)) return `hoje às ${hm}`;
	if (sameDay(when, new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1))) return `amanhã às ${hm}`;
	return `${WEEKDAYS[when.getDay()]?.short ?? ""} ${when.getDate()} ${MONTHS[when.getMonth()]} às ${hm}`;
}
var field$1 = "w-full rounded-2xl border border-line bg-surface-2 px-4 py-3 text-fg outline-none focus:border-accent";
function nudgeNotify$1() {
	if (typeof Notification === "undefined") return;
	if (Notification.permission !== "default") return;
	const { notifyDismissed, setNotifyPrompt } = useApp.getState();
	if (notifyDismissed) return;
	setNotifyPrompt(true);
}
function AlarmsView() {
	const now = useNow();
	const alarms = useApp((state) => state.alarms);
	const addAlarm = useApp((state) => state.addAlarm);
	const [time, setTime] = (0, import_react.useState)("07:00");
	const [label, setLabel] = (0, import_react.useState)("");
	const [days, setDays] = (0, import_react.useState)([
		0,
		1,
		2,
		3,
		4,
		5,
		6
	]);
	const [error, setError] = (0, import_react.useState)(null);
	const ordered = [...alarms].sort((a, b) => a.hour * 60 + a.minute - (b.hour * 60 + b.minute));
	const next = now ? soonest(alarms, now) : null;
	const snoozing = next != null && next.alarm.snoozeUntil === next.when.getTime();
	function createAlarm() {
		if (alarms.length >= 24) {
			setError("Apaga um alarme antes de criar outro.");
			return;
		}
		const parsed = parseTime(time);
		if (!parsed) {
			setError("Escolhe um horário.");
			return;
		}
		addAlarm({
			id: uid(),
			label: label.trim(),
			hour: parsed.hour,
			minute: parsed.minute,
			enabled: true,
			days: [...days].sort((a, b) => a - b),
			lastFiredKey: null,
			snoozeUntil: null,
			onceDone: false
		});
		setLabel("");
		setError(null);
		nudgeNotify$1();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "Alarme"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-6xl font-semibold tabular-nums text-fg",
					children: now ? clock(now) : "--:--"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold tabular-nums text-muted",
					children: now ? String(now.getSeconds()).padStart(2, "0") : ""
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: next && now ? `Próximo: ${formatWhen(next.when, now)}${snoozing ? " · soneca" : ""}${next.alarm.label ? ` · ${next.alarm.label}` : ""}` : "Nenhum alarme armado."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Toca enquanto o appnoteSO estiver aberto."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 flex flex-col gap-4",
				onSubmit: (event) => {
					event.preventDefault();
					createAlarm();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "horario",
						className: "mb-1 block text-sm text-muted",
						children: "Horário"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "horario",
						type: "time",
						step: 60,
						required: true,
						value: time,
						onChange: (event) => setTime(event.target.value),
						className: `${field$1} font-display text-4xl font-semibold tabular-nums`
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "nome-alarme",
						className: "mb-1 block text-sm text-muted",
						children: "Nome"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "nome-alarme",
						type: "text",
						maxLength: 80,
						value: label,
						placeholder: "acordar, remédio, água…",
						onChange: (event) => setLabel(event.target.value),
						className: field$1
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-sm text-muted",
							children: "Repete"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-7 gap-1",
							children: WEEKDAYS.map((day) => {
								const on = days.includes(day.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": on,
									"aria-label": day.long,
									className: `h-11 rounded-full text-xs font-semibold ${on ? "bg-accent text-accent-ink" : "bg-surface-2 text-muted"}`,
									onClick: () => setDays((current) => current.includes(day.id) ? current.filter((item) => item !== day.id) : [...current, day.id]),
									children: day.short
								}, day.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: days.length === 0 ? "Toca uma vez e desliga." : "Repete nos dias marcados."
						})
					] }),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-accent",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink",
						children: "Criar alarme"
					})
				]
			}),
			ordered.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 flex flex-col gap-3",
				children: ordered.map((alarm) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlarmRow, { alarm }) }, alarm.id))
			})
		]
	});
}
function AlarmRow({ alarm }) {
	const patchAlarm = useApp((state) => state.patchAlarm);
	const deleteAlarm = useApp((state) => state.deleteAlarm);
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const time = padTime(alarm.hour, alarm.minute);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "rounded-2xl bg-surface px-4 py-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `min-w-0 ${alarm.enabled ? "" : "opacity-50"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl font-semibold tabular-nums text-fg",
						children: time
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-fg",
						children: alarm.label || "Alarme"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: daysLabel(alarm.days)
					})
				]
			}), confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 flex-col items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex h-11 items-center text-sm font-semibold text-accent",
					onClick: () => deleteAlarm(alarm.id),
					children: "Apagar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex h-11 items-center text-sm text-muted",
					onClick: () => setConfirming(false),
					children: "Cancelar"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex shrink-0 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "switch",
					"aria-checked": alarm.enabled,
					"aria-label": `${time} ${alarm.enabled ? "ligado" : "desligado"}`,
					className: "grid h-11 w-14 place-items-center",
					onClick: () => patchAlarm(alarm.id, alarm.enabled ? {
						enabled: false,
						snoozeUntil: null
					} : { enabled: true }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `relative h-7 w-12 rounded-full ${alarm.enabled ? "bg-accent" : "bg-line"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 left-0.5 size-6 rounded-full bg-paper transition-transform motion-reduce:transition-none ${alarm.enabled ? "translate-x-5" : ""}` })
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": `Apagar alarme ${time}`,
					className: "grid size-11 place-items-center text-muted",
					onClick: () => setConfirming(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
						className: "size-4",
						"aria-hidden": true
					})
				})]
			})]
		})
	});
}
var sheetField = "w-full rounded-2xl border border-ink/15 bg-ink/5 px-4 py-3 text-ink outline-none placeholder:text-ink-soft focus:border-accent-deep";
function nudgeNotify() {
	if (typeof Notification === "undefined") return;
	if (Notification.permission !== "default") return;
	const { notifyDismissed, setNotifyPrompt } = useApp.getState();
	if (notifyDismissed) return;
	setNotifyPrompt(true);
}
function parseReminder(value) {
	if (!value) return {
		ok: true,
		at: null
	};
	const at = new Date(value).getTime();
	if (Number.isNaN(at)) return { ok: false };
	if (at < Date.now() - 3e4) return { ok: false };
	return {
		ok: true,
		at
	};
}
function toLocalInput(ts) {
	if (!ts) return "";
	const date = new Date(ts);
	const pad = (part) => String(part).padStart(2, "0");
	return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function NotesView() {
	const draft = useApp((state) => state.draft);
	const draftReminder = useApp((state) => state.draftReminder);
	const setDraft = useApp((state) => state.setDraft);
	const setDraftReminder = useApp((state) => state.setDraftReminder);
	const clearDraft = useApp((state) => state.clearDraft);
	const addNote = useApp((state) => state.addNote);
	const notes = useApp((state) => state.notes);
	const [reminderOpen, setReminderOpen] = (0, import_react.useState)(() => draftReminder !== "");
	const [error, setError] = (0, import_react.useState)(null);
	function save() {
		const body = draft.trim();
		if (!body) return;
		const parsed = parseReminder(draftReminder);
		if (!parsed.ok) {
			setError("Esse horário já passou.");
			return;
		}
		const now = Date.now();
		addNote({
			id: uid(),
			body,
			createdAt: now,
			updatedAt: now,
			reminderAt: parsed.at,
			reminderFired: false
		});
		clearDraft();
		setReminderOpen(false);
		setError(null);
		if (parsed.at) nudgeNotify();
	}
	const ordered = [...notes].sort((a, b) => b.updatedAt - a.updatedAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "sr-only",
			children: "Notas"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "sheet rise rounded-2xl py-5 pr-5 pl-7",
			onSubmit: (event) => {
				event.preventDefault();
				save();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					htmlFor: "nota",
					className: "sr-only",
					children: "Nota"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					id: "nota",
					value: draft,
					maxLength: 12e3,
					placeholder: "Escreve o que está pesando. Só neste aparelho.",
					className: `${sheetField} min-h-36 text-lg leading-normal`,
					onChange: (event) => {
						setDraft(event.target.value);
						setError(null);
					},
					onKeyDown: (event) => {
						if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
							event.preventDefault();
							save();
						}
					}
				}),
				reminderOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "lembrete",
						className: "mb-1 block text-sm text-ink-soft",
						children: "Quando avisar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "lembrete",
						type: "datetime-local",
						value: draftReminder,
						className: `${sheetField} min-h-11`,
						onChange: (event) => {
							setDraftReminder(event.target.value);
							setError(null);
						}
					})]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-accent-deep",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": reminderOpen,
						className: "inline-flex h-11 items-center gap-2 text-sm font-semibold text-accent-deep",
						onClick: () => {
							if (reminderOpen) {
								setDraftReminder("");
								setError(null);
							}
							setReminderOpen((open) => !open);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
							className: "size-4",
							"aria-hidden": true
						}), "Lembrete"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-xs text-ink-soft sm:inline",
							children: "Ctrl+Enter guarda"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: !draft.trim(),
							className: "inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink disabled:opacity-40",
							children: "Guardar"
						})]
					})]
				})
			]
		}),
		ordered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-1 pt-6 text-base text-muted italic",
			children: "Nada escrito ainda. Quando precisar, deixa aqui."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-5 flex flex-col gap-4",
			children: ordered.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoteCard, { note }) }, note.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "px-1 pt-8 text-xs text-muted",
			children: "Fica só neste navegador. Se limpar os dados do site, as notas somem."
		})
	] });
}
function NoteCard({ note }) {
	const updateNote = useApp((state) => state.updateNote);
	const deleteNote = useApp((state) => state.deleteNote);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const [body, setBody] = (0, import_react.useState)(note.body);
	const [reminder, setReminder] = (0, import_react.useState)(toLocalInput(note.reminderAt));
	const [error, setError] = (0, import_react.useState)(null);
	const long = note.body.length > 480 || note.body.split("\n").length > 8;
	function saveEdit() {
		const next = body.trim();
		if (!next) {
			setError("Escreve alguma coisa.");
			return;
		}
		const parsed = parseReminder(reminder);
		if (!parsed.ok) {
			setError("Esse horário já passou.");
			return;
		}
		const sameReminder = note.reminderAt === parsed.at;
		updateNote(note.id, {
			body: next,
			updatedAt: Date.now(),
			reminderAt: parsed.at,
			reminderFired: sameReminder ? note.reminderFired : false
		});
		if (parsed.at && !sameReminder) nudgeNotify();
		setEditing(false);
		setError(null);
	}
	if (editing) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "sheet rounded-2xl py-5 pr-5 pl-7",
		onSubmit: (event) => {
			event.preventDefault();
			saveEdit();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: `edit-${note.id}`,
				className: "sr-only",
				children: "Editar nota"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: `edit-${note.id}`,
				value: body,
				maxLength: 12e3,
				className: `${sheetField} min-h-36 text-lg leading-normal`,
				onChange: (event) => {
					setBody(event.target.value);
					setError(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: `edit-reminder-${note.id}`,
				className: "mt-3 mb-1 block text-sm text-ink-soft",
				children: "Quando avisar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: `edit-reminder-${note.id}`,
				type: "datetime-local",
				value: reminder,
				className: `${sheetField} min-h-11`,
				onChange: (event) => {
					setReminder(event.target.value);
					setError(null);
				}
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-accent-deep",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink",
					children: "Salvar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex h-11 items-center justify-center rounded-full px-4 text-sm font-semibold text-ink-soft",
					onClick: () => {
						setEditing(false);
						setBody(note.body);
						setReminder(toLocalInput(note.reminderAt));
						setError(null);
					},
					children: "Cancelar"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "sheet rise rounded-2xl py-4 pr-3 pl-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
					className: "pt-2 text-sm text-ink-soft",
					dateTime: new Date(note.updatedAt).toISOString(),
					children: ago(note.updatedAt)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex",
					children: confirming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 pr-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex h-11 items-center px-2 text-sm font-semibold text-accent-deep",
							onClick: () => deleteNote(note.id),
							children: "Apagar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex h-11 items-center px-2 text-sm text-ink-soft",
							onClick: () => setConfirming(false),
							children: "Cancelar"
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Editar nota",
						className: "grid size-11 place-items-center text-ink-soft",
						onClick: () => {
							setBody(note.body);
							setReminder(toLocalInput(note.reminderAt));
							setEditing(true);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {
							className: "size-4",
							"aria-hidden": true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Apagar nota",
						className: "grid size-11 place-items-center text-ink-soft",
						onClick: () => setConfirming(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-4",
							"aria-hidden": true
						})
					})] })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `text-lg leading-normal break-words whitespace-pre-wrap ${long && !expanded ? "max-h-40 overflow-hidden" : ""}`,
				children: note.body
			}),
			long && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-2 text-sm font-semibold text-accent-deep",
				onClick: () => setExpanded((open) => !open),
				children: expanded ? "Recolher" : "Ler tudo"
			}),
			note.reminderAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 flex items-center gap-2 text-sm text-accent-deep",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
					className: "size-4 shrink-0",
					"aria-hidden": true
				}), note.reminderFired ? `avisado · ${reminderWhen(note.reminderAt)}` : reminderWhen(note.reminderAt)]
			})
		]
	});
}
var ctx = null;
var timer = 0;
var playing = false;
async function unlockAudio() {
	if (typeof window === "undefined") return;
	ctx = ctx ?? new AudioContext();
	if (ctx.state === "suspended") await ctx.resume();
}
function alarmAudible() {
	return ctx?.state === "running";
}
function tone(frequency, delay, sustain, peak) {
	if (!ctx || ctx.state !== "running") return;
	const start = ctx.currentTime + delay;
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = "sine";
	osc.frequency.value = frequency;
	gain.gain.setValueAtTime(1e-4, start);
	gain.gain.exponentialRampToValueAtTime(peak, start + .03);
	gain.gain.exponentialRampToValueAtTime(1e-4, start + sustain);
	osc.connect(gain);
	gain.connect(ctx.destination);
	osc.start(start);
	osc.stop(start + sustain + .02);
}
function alarmChime() {
	tone(523.25, 0, .42, .14);
	tone(659.25, .16, .42, .12);
	tone(783.99, .32, .5, .1);
}
function startAlarmTone() {
	try {
		unlockAudio();
		if (playing) return;
		playing = true;
		alarmChime();
		timer = window.setInterval(alarmChime, 1400);
	} catch {
		playing = false;
	}
}
function stopAlarmTone() {
	playing = false;
	window.clearInterval(timer);
	timer = 0;
}
function playReminderChime() {
	try {
		unlockAudio();
		tone(659.25, 0, .35, .08);
		tone(880, .14, .4, .06);
	} catch {}
}
var seen = /* @__PURE__ */ new Set();
var GRACE_MS = 9e4;
function claim(key, lastFiredKey) {
	if (lastFiredKey === key || seen.has(key)) return false;
	seen.add(key);
	return true;
}
function notify(title, body) {
	if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
	try {
		new Notification(title, { body });
	} catch {}
}
function pickAlarm(alarm, now, patchAlarm) {
	if (!alarm.enabled) return null;
	if (alarm.snoozeUntil != null) {
		const delta = now.getTime() - alarm.snoozeUntil;
		if (delta < 0) return null;
		if (delta < GRACE_MS) {
			const key = `snooze:${alarm.id}:${alarm.snoozeUntil}`;
			return claim(key, alarm.lastFiredKey) ? key : null;
		}
		patchAlarm(alarm.id, { snoozeUntil: null });
	}
	const minute = dueMinuteKey(alarm, now);
	if (minute && claim(minute, alarm.lastFiredKey)) return minute;
	return null;
}
function Scheduler() {
	const alarms = useApp((state) => state.alarms);
	const notes = useApp((state) => state.notes);
	const inbox = useApp((state) => state.inbox);
	const notifyPrompt = useApp((state) => state.notifyPrompt);
	const dismissNotify = useApp((state) => state.dismissNotify);
	const dismissInbox = useApp((state) => state.dismissInbox);
	const [ring, setRing] = (0, import_react.useState)(null);
	const ringRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const unlock = () => {
			unlockAudio();
		};
		window.addEventListener("pointerdown", unlock, { once: true });
		return () => window.removeEventListener("pointerdown", unlock);
	}, []);
	(0, import_react.useEffect)(() => {
		let alive = true;
		const tick = () => {
			if (!alive) return;
			const state = useApp.getState();
			const now = /* @__PURE__ */ new Date();
			if (!ringRef.current) for (const alarm of state.alarms) {
				const key = pickAlarm(alarm, now, state.patchAlarm);
				if (!key) continue;
				const next = {
					alarmId: alarm.id,
					key,
					label: alarm.label,
					once: alarm.days.length === 0
				};
				ringRef.current = next;
				setRing(next);
				startAlarmTone();
				if (document.visibilityState === "hidden") notify("Alarme", alarm.label || "Está na hora.");
				break;
			}
			for (const note of state.notes) {
				if (!note.reminderAt || note.reminderFired || note.reminderAt > Date.now()) continue;
				state.markReminderFired(note.id);
				state.pushInbox(note.id);
				const text = note.body.trim().split("\n")[0]?.slice(0, 160) || "Uma nota sua";
				if (document.visibilityState === "hidden") notify("Lembrete", text);
				else if (!ringRef.current) playReminderChime();
			}
		};
		tick();
		const id = window.setInterval(tick, 1e3);
		return () => {
			alive = false;
			window.clearInterval(id);
			if (ringRef.current) {
				seen.delete(ringRef.current.key);
				ringRef.current = null;
				stopAlarmTone();
			}
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ring) return;
		if (!alarms.some((alarm) => alarm.id === ring.alarmId)) {
			stopAlarmTone();
			ringRef.current = null;
			setRing(null);
		}
	}, [alarms, ring]);
	const openNotes = inbox.map((id) => notes.find((note) => note.id === id)).filter((note) => note != null);
	(0, import_react.useEffect)(() => {
		for (const id of inbox) if (!notes.some((note) => note.id === id)) dismissInbox(id);
	}, [
		inbox,
		notes,
		dismissInbox
	]);
	function closeRing(snoozeMinutes) {
		const current = ringRef.current;
		if (!current) return;
		stopAlarmTone();
		const patch = snoozeMinutes == null ? {
			lastFiredKey: current.key,
			snoozeUntil: null,
			...current.once ? {
				enabled: false,
				onceDone: true
			} : {}
		} : {
			lastFiredKey: current.key,
			snoozeUntil: Date.now() + snoozeMinutes * 6e4,
			...current.once ? { onceDone: true } : {}
		};
		useApp.getState().patchAlarm(current.alarmId, patch);
		ringRef.current = null;
		setRing(null);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		openNotes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-live": "polite",
			className: "fixed inset-x-4 top-4 z-40 mx-auto flex max-w-md flex-col gap-2",
			children: openNotes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sheet rounded-2xl px-5 py-4 pl-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-accent-deep",
						children: "Lembrete"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-3 text-base",
						children: note.body.trim() || "Uma nota sua"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-3 h-11 text-sm font-semibold text-accent-deep",
						onClick: () => dismissInbox(note.id),
						children: "Fechar"
					})
				]
			}, note.id))
		}),
		notifyPrompt && !ring && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "fixed inset-x-4 bottom-24 z-40 mx-auto max-w-md rounded-2xl bg-surface p-4 md:bottom-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-semibold text-fg",
					children: "Avisos"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Com o app aberto, o alarme toca aqui. Se permitir, o celular também avisa com a aba em segundo plano."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink",
						onClick: () => {
							Notification.requestPermission().finally(() => dismissNotify());
						},
						children: "Permitir avisos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-11 items-center justify-center rounded-full px-4 text-sm font-semibold text-muted",
						onClick: dismissNotify,
						children: "Agora não"
					})]
				})
			]
		}),
		ring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ringer, {
			ring,
			onSnooze: (minutes) => closeRing(minutes),
			onStop: () => closeRing(null)
		})
	] });
}
function Ringer({ ring, onSnooze, onStop }) {
	const now = useNow();
	const stopRef = (0, import_react.useRef)(null);
	const onStopRef = (0, import_react.useRef)(onStop);
	const [silent, setSilent] = (0, import_react.useState)(false);
	onStopRef.current = onStop;
	(0, import_react.useEffect)(() => {
		const previous = document.title;
		const overflow = document.body.style.overflow;
		document.title = "Alarme · appnoteSO";
		document.body.style.overflow = "hidden";
		stopRef.current?.focus();
		const check = window.setTimeout(() => setSilent(!alarmAudible()), 250);
		const onKey = (event) => {
			if (event.key === "Escape") onStopRef.current();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.title = previous;
			document.body.style.overflow = overflow;
			window.clearTimeout(check);
			window.removeEventListener("keydown", onKey);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "alertdialog",
		"aria-modal": "true",
		"aria-labelledby": "ring-title",
		className: "fixed inset-0 z-50 flex flex-col items-center justify-center gap-6 bg-bg px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: "ring-title",
				className: "attn text-sm font-semibold text-accent",
				children: "Alarme"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-6xl font-semibold tabular-nums text-fg",
				children: now ? clock(now) : "--:--"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-xl text-fg",
				children: ring.label || "Está na hora."
			}),
			silent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 text-sm font-semibold text-accent",
				onClick: () => {
					unlockAudio().then(() => {
						stopAlarmTone();
						startAlarmTone();
						window.setTimeout(() => setSilent(!alarmAudible()), 200);
					});
				},
				children: "Tocar o som"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full max-w-sm flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-12 items-center justify-center rounded-full bg-surface-2 text-sm font-semibold text-fg",
						onClick: () => onSnooze(5),
						children: "Soneca 5 min"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-12 items-center justify-center rounded-full bg-surface-2 text-sm font-semibold text-fg",
						onClick: () => onSnooze(10),
						children: "Soneca 10 min"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						ref: stopRef,
						type: "button",
						className: "inline-flex h-12 items-center justify-center rounded-full bg-accent text-sm font-semibold text-accent-ink",
						onClick: onStop,
						children: "Desligar"
					})
				]
			})
		]
	});
}
var SHORT_DAYS = [
	"dom",
	"seg",
	"ter",
	"qua",
	"qui",
	"sex",
	"sáb"
];
var cache = null;
var FRESH_MS = 12e5;
function describeWeather(code, isDay) {
	if (code === 0) return {
		label: "Céu limpo",
		icon: isDay ? "sun" : "moon"
	};
	if (code === 1 || code === 2) return {
		label: code === 1 ? "Quase limpo" : "Parcialmente nublado",
		icon: isDay ? "cloud-sun" : "cloud-moon"
	};
	if (code === 3) return {
		label: "Nublado",
		icon: "cloud"
	};
	if (code === 45 || code === 48) return {
		label: "Neblina",
		icon: "fog"
	};
	if (code >= 51 && code <= 57) return {
		label: "Garoa",
		icon: "drizzle"
	};
	if (code >= 61 && code <= 67) return {
		label: "Chuva",
		icon: "rain"
	};
	if (code >= 80 && code <= 82) return {
		label: "Pancadas",
		icon: "rain"
	};
	if (code >= 71 && code <= 77 || code === 85 || code === 86) return {
		label: "Neve",
		icon: "snow"
	};
	if (code >= 95) return {
		label: "Trovoada",
		icon: "storm"
	};
	return {
		label: "Tempo instável",
		icon: "cloud"
	};
}
function cacheKey(place) {
	return `${place.latitude.toFixed(2)},${place.longitude.toFixed(2)}`;
}
function peekForecast(place) {
	if (!cache || cache.key !== cacheKey(place)) return null;
	if (Date.now() - cache.at > FRESH_MS) return null;
	return cache.data;
}
function asNum(value) {
	const number = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
	return Number.isFinite(number) ? number : null;
}
function parseLocal(value, offsetSeconds) {
	const match = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}))?/.exec(value);
	if (!match) return null;
	return Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]), match[4] ? Number(match[4]) : 0, match[5] ? Number(match[5]) : 0) - offsetSeconds * 1e3;
}
function partsInZone(ts, offsetSeconds) {
	const shifted = new Date(ts + offsetSeconds * 1e3);
	return {
		year: shifted.getUTCFullYear(),
		month: shifted.getUTCMonth(),
		day: shifted.getUTCDate(),
		hour: shifted.getUTCHours(),
		weekday: shifted.getUTCDay()
	};
}
function shiftDay(parts, days) {
	const next = new Date(Date.UTC(parts.year, parts.month, parts.day + days));
	return {
		year: next.getUTCFullYear(),
		month: next.getUTCMonth(),
		day: next.getUTCDate()
	};
}
function sameDate(a, b) {
	return a.year === b.year && a.month === b.month && a.day === b.day;
}
async function searchCities(query, signal) {
	const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
	url.searchParams.set("name", query);
	url.searchParams.set("count", "5");
	url.searchParams.set("language", "pt");
	url.searchParams.set("format", "json");
	const response = await fetch(url, { signal });
	if (!response.ok) throw new Error("busca");
	const data = await response.json();
	if (!Array.isArray(data.results)) return [];
	const places = [];
	for (const item of data.results) {
		if (!item || typeof item !== "object") continue;
		const row = item;
		const latitude = asNum(row.latitude);
		const longitude = asNum(row.longitude);
		if (latitude == null || longitude == null || typeof row.name !== "string") continue;
		places.push({
			id: typeof row.id === "number" ? row.id : Math.round(latitude * 1e3),
			name: row.name,
			admin1: typeof row.admin1 === "string" ? row.admin1 : "",
			country: typeof row.country === "string" ? row.country : "",
			latitude,
			longitude
		});
	}
	return places;
}
async function placeFromCoords(latitude, longitude, signal) {
	let name = "Onde você está";
	let admin1 = "";
	let country = "";
	try {
		const url = new URL("https://api.bigdatacloud.net/data/reverse-geocode-client");
		url.searchParams.set("latitude", String(latitude));
		url.searchParams.set("longitude", String(longitude));
		url.searchParams.set("localityLanguage", "pt");
		const response = await fetch(url, { signal });
		if (response.ok) {
			const data = await response.json();
			const city = typeof data.city === "string" && data.city ? data.city : "";
			const locality = typeof data.locality === "string" ? data.locality : "";
			name = city || locality || name;
			admin1 = typeof data.principalSubdivision === "string" ? data.principalSubdivision : "";
			country = typeof data.countryName === "string" ? data.countryName : "";
		}
	} catch (error) {
		if (signal?.aborted) throw error;
	}
	return {
		id: Math.round(latitude * 1e3) * 1e6 + Math.round(longitude * 1e3),
		name,
		admin1,
		country,
		latitude,
		longitude
	};
}
async function loadForecast(place, signal, force = false) {
	const key = cacheKey(place);
	if (!force && cache && cache.key === key && Date.now() - cache.at < FRESH_MS) return cache.data;
	const url = new URL("https://api.open-meteo.com/v1/forecast");
	url.searchParams.set("latitude", String(place.latitude));
	url.searchParams.set("longitude", String(place.longitude));
	url.searchParams.set("current", "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,is_day");
	url.searchParams.set("hourly", "temperature_2m,precipitation_probability,weather_code,is_day");
	url.searchParams.set("daily", "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max");
	url.searchParams.set("timezone", "auto");
	url.searchParams.set("forecast_days", "5");
	url.searchParams.set("wind_speed_unit", "kmh");
	url.searchParams.set("temperature_unit", "celsius");
	const response = await fetch(url, { signal });
	if (!response.ok) throw new Error("previsão");
	const data = await response.json();
	const offsetSeconds = asNum(data.utc_offset_seconds) ?? 0;
	const current = data.current;
	const temp = asNum(current?.temperature_2m);
	const apparent = asNum(current?.apparent_temperature);
	const humidity = asNum(current?.relative_humidity_2m);
	const wind = asNum(current?.wind_speed_10m);
	const code = asNum(current?.weather_code);
	if (!current || temp == null || apparent == null || humidity == null || wind == null || code == null) throw new Error("previsão");
	const hourly = data.hourly;
	const hourlyTime = Array.isArray(hourly?.time) ? hourly.time : [];
	const hourlyTemp = Array.isArray(hourly?.temperature_2m) ? hourly.temperature_2m : [];
	const hourlyPop = Array.isArray(hourly?.precipitation_probability) ? hourly.precipitation_probability : [];
	const hourlyCode = Array.isArray(hourly?.weather_code) ? hourly.weather_code : [];
	const hourlyDay = Array.isArray(hourly?.is_day) ? hourly.is_day : [];
	const now = Date.now();
	const hours = [];
	for (let index = 0; index < hourlyTime.length; index += 1) {
		if (typeof hourlyTime[index] !== "string") continue;
		const time = parseLocal(hourlyTime[index], offsetSeconds);
		const hourTemp = asNum(hourlyTemp[index]);
		const hourCode = asNum(hourlyCode[index]);
		if (time == null || hourTemp == null || hourCode == null) continue;
		if (time < now - 18e5) continue;
		const zoned = partsInZone(time, offsetSeconds);
		hours.push({
			label: `${zoned.hour}h`,
			temp: Math.round(hourTemp),
			pop: Math.round(asNum(hourlyPop[index]) ?? 0),
			code: hourCode,
			isDay: hourlyDay[index] !== 0
		});
		if (hours.length === 18) break;
	}
	const daily = data.daily;
	const dailyTime = Array.isArray(daily?.time) ? daily.time : [];
	const dailyCode = Array.isArray(daily?.weather_code) ? daily.weather_code : [];
	const dailyMax = Array.isArray(daily?.temperature_2m_max) ? daily.temperature_2m_max : [];
	const dailyMin = Array.isArray(daily?.temperature_2m_min) ? daily.temperature_2m_min : [];
	const dailyPop = Array.isArray(daily?.precipitation_probability_max) ? daily.precipitation_probability_max : [];
	const today = partsInZone(now, offsetSeconds);
	const tomorrow = shiftDay(today, 1);
	const days = [];
	for (let index = 0; index < dailyTime.length; index += 1) {
		if (typeof dailyTime[index] !== "string") continue;
		const time = parseLocal(dailyTime[index], offsetSeconds);
		const max = asNum(dailyMax[index]);
		const min = asNum(dailyMin[index]);
		const dayCode = asNum(dailyCode[index]);
		if (time == null || max == null || min == null || dayCode == null) continue;
		const zoned = partsInZone(time, offsetSeconds);
		let label = SHORT_DAYS[zoned.weekday] ?? "";
		if (sameDate(zoned, today)) label = "hoje";
		else if (sameDate(zoned, tomorrow)) label = "amanhã";
		days.push({
			label,
			max: Math.round(max),
			min: Math.round(min),
			pop: Math.round(asNum(dailyPop[index]) ?? 0),
			code: dayCode
		});
	}
	const forecast = {
		fetchedAt: Date.now(),
		offsetSeconds,
		current: {
			temp: Math.round(temp),
			apparent: Math.round(apparent),
			humidity: Math.round(humidity),
			wind: Math.round(wind),
			code,
			isDay: current.is_day !== 0
		},
		hours,
		days
	};
	cache = {
		key,
		at: forecast.fetchedAt,
		data: forecast
	};
	return forecast;
}
var ICONS = {
	sun: Sun,
	moon: Moon,
	"cloud-sun": CloudSun,
	"cloud-moon": CloudMoon,
	cloud: Cloud,
	fog: CloudFog,
	drizzle: CloudDrizzle,
	rain: CloudRain,
	snow: CloudSnow,
	storm: CloudLightning
};
var field = "w-full min-h-11 rounded-2xl border border-line bg-surface-2 px-4 py-3 text-fg outline-none focus:border-accent";
function placeDetail(place) {
	return [place.admin1, place.country].filter((part) => part && part !== place.name).join(" · ");
}
function SkyGlyph({ code, isDay, className }) {
	const { icon } = describeWeather(code, isDay);
	const Icon = ICONS[icon];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		"aria-hidden": true
	});
}
function WeatherView() {
	const place = useApp((state) => state.place);
	const setPlace = useApp((state) => state.setPlace);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [results, setResults] = (0, import_react.useState)([]);
	const [searching, setSearching] = (0, import_react.useState)(false);
	const [settledQuery, setSettledQuery] = (0, import_react.useState)("");
	const [searchError, setSearchError] = (0, import_react.useState)(null);
	const [locating, setLocating] = (0, import_react.useState)(false);
	const [locError, setLocError] = (0, import_react.useState)(null);
	const [forecast, setForecast] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [forecastError, setForecastError] = (0, import_react.useState)(null);
	const [refreshToken, setRefreshToken] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const q = query.trim();
		if (q.length < 2) {
			setResults([]);
			setSearching(false);
			setSettledQuery("");
			return;
		}
		const ctrl = new AbortController();
		const timeout = window.setTimeout(() => {
			setSearching(true);
			searchCities(q, ctrl.signal).then((found) => {
				if (ctrl.signal.aborted) return;
				setResults(found);
				setSearchError(null);
				setSettledQuery(q);
			}).catch((error) => {
				if (error instanceof DOMException && error.name === "AbortError") return;
				if (!ctrl.signal.aborted) setSearchError("Não deu pra buscar agora.");
			}).finally(() => {
				if (!ctrl.signal.aborted) setSearching(false);
			});
		}, 300);
		return () => {
			ctrl.abort();
			window.clearTimeout(timeout);
		};
	}, [query]);
	(0, import_react.useEffect)(() => {
		if (!place) return;
		const ctrl = new AbortController();
		const cached = refreshToken === 0 ? peekForecast(place) : null;
		if (cached) setForecast(cached);
		setLoading(!cached);
		setForecastError(null);
		loadForecast(place, ctrl.signal, refreshToken > 0).then((data) => {
			if (ctrl.signal.aborted) return;
			setForecast(data);
			setForecastError(null);
		}).catch((error) => {
			if (error instanceof DOMException && error.name === "AbortError") return;
			if (!ctrl.signal.aborted) setForecastError("Não consegui buscar a previsão.");
		}).finally(() => {
			if (!ctrl.signal.aborted) setLoading(false);
		});
		return () => ctrl.abort();
	}, [place, refreshToken]);
	function choose(next) {
		setPlace(next);
		setEditing(false);
		setQuery("");
		setResults([]);
		setLocError(null);
		setRefreshToken(0);
	}
	function locate() {
		if (!navigator.geolocation) {
			setLocError("Este navegador não entrega localização.");
			return;
		}
		setLocating(true);
		setLocError(null);
		navigator.geolocation.getCurrentPosition((position) => {
			placeFromCoords(position.coords.latitude, position.coords.longitude).then((next) => {
				choose(next);
			}).catch(() => {
				setLocError("Não consegui usar sua localização. Busca a cidade pelo nome.");
			}).finally(() => setLocating(false));
		}, () => {
			setLocating(false);
			setLocError("Não consegui usar sua localização. Busca a cidade pelo nome.");
		}, {
			enableHighAccuracy: false,
			timeout: 8e3,
			maximumAge: 6e5
		});
	}
	const showSearch = !place || editing;
	const emptySearch = settledQuery.length >= 2 && settledQuery === query.trim() && !searching && results.length === 0;
	const browserOffset = -(/* @__PURE__ */ new Date()).getTimezoneOffset() * 60;
	const otherZone = forecast != null && forecast.offsetSeconds !== browserOffset;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "sr-only",
				children: "Tempo"
			}),
			showSearch && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "cidade",
						className: "text-sm text-muted",
						children: "Cidade"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "cidade",
						type: "search",
						value: query,
						placeholder: "Buscar cidade",
						autoComplete: "off",
						className: field,
						onChange: (event) => setQuery(event.target.value)
					}),
					searching && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Buscando…"
					}),
					searchError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-accent",
						children: searchError
					}),
					emptySearch && !searchError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Nenhuma cidade com esse nome."
					}),
					results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "overflow-hidden rounded-2xl border border-line bg-surface",
						children: results.map((city) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "flex min-h-11 w-full flex-col items-start justify-center px-4 py-2 text-left hover:bg-surface-2",
							onClick: () => choose(city),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: city.name
							}), placeDetail(city) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-muted",
								children: placeDetail(city)
							})]
						}) }, `${city.id}-${city.latitude}`))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locating,
						className: "inline-flex h-11 items-center justify-center gap-2 rounded-full bg-surface-2 px-5 text-sm font-semibold text-fg disabled:opacity-40",
						onClick: locate,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, {
							className: "size-4",
							"aria-hidden": true
						}), locating ? "Buscando você…" : "Usar minha localização"]
					}),
					locError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-accent",
						children: locError
					}),
					place && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-11 self-start text-sm font-semibold text-muted",
						onClick: () => setEditing(false),
						children: "Cancelar"
					})
				]
			}),
			place && !showSearch && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-semibold text-fg",
						children: place.name
					}), placeDetail(place) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: placeDetail(place)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 shrink-0 text-sm font-semibold text-accent",
					onClick: () => setEditing(true),
					children: "Trocar"
				})]
			}),
			place && loading && !forecast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: "Buscando a previsão…"
			}),
			place && forecastError && !forecast && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: forecastError
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-3 inline-flex h-11 items-center justify-center rounded-full bg-accent px-5 text-sm font-semibold text-accent-ink",
					onClick: () => setRefreshToken((token) => token + 1),
					children: "Tentar de novo"
				})]
			}),
			forecast && place && !showSearch && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-7xl font-semibold tabular-nums leading-none text-fg",
							children: [forecast.current.temp, "°"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkyGlyph, {
							code: forecast.current.code,
							isDay: forecast.current.isDay,
							className: "mb-1 size-10 text-accent"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-lg text-fg",
						children: describeWeather(forecast.current.code, forecast.current.isDay).label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"sensação ",
							forecast.current.apparent,
							"° · umidade ",
							forecast.current.humidity,
							"% · vento ",
							forecast.current.wind,
							" ",
							"km/h"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							"atualizado às ",
							clock(new Date(forecast.fetchedAt)),
							forecastError ? " · sem conexão, esta é a última previsão" : ""
						]
					}),
					forecast.hours.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-xl font-semibold text-fg",
								children: "Próximas horas"
							}), otherZone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "horário da cidade"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "scroll-x -mx-4 flex gap-2 px-4",
							children: forecast.hours.map((hour, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex w-16 shrink-0 flex-col items-center gap-1 rounded-2xl bg-surface py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: hour.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkyGlyph, {
										code: hour.code,
										isDay: hour.isDay,
										className: "size-5 text-fg"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm tabular-nums text-fg",
										children: [hour.temp, "°"]
									}),
									hour.pop >= 20 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs tabular-nums text-accent",
										children: [hour.pop, "%"]
									})
								]
							}, `${hour.label}-${index}`))
						})]
					}),
					forecast.days.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-xl font-semibold text-fg",
							children: "Próximos dias"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2",
							children: forecast.days.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 border-t border-line py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-20 text-sm text-muted",
										children: day.label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkyGlyph, {
										code: day.code,
										isDay: true,
										className: "size-5 text-fg"
									}),
									day.pop >= 20 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs tabular-nums text-accent",
										children: [day.pop, "%"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-auto tabular-nums text-fg",
										children: [day.max, "°"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "w-10 text-right tabular-nums text-muted",
										children: [day.min, "°"]
									})
								]
							}, day.label))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mt-6 h-11 text-sm font-semibold text-accent",
						onClick: () => setRefreshToken((token) => token + 1),
						children: "Atualizar"
					})
				]
			}),
			!place && !showSearch && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-muted",
				children: "Escolhe uma cidade pra ver o tempo."
			})
		]
	});
}
var TABS = [
	{
		id: "notas",
		label: "Notas",
		icon: NotebookPen
	},
	{
		id: "alarme",
		label: "Alarme",
		icon: AlarmClock
	},
	{
		id: "tempo",
		label: "Tempo",
		icon: CloudSun
	}
];
function App() {
	const hydrated = useHydrated();
	const view = useApp((state) => state.view);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, { showNav: hydrated }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto w-full max-w-2xl px-4 pt-6 pb-28 md:pb-12",
				children: [
					!hydrated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-muted",
						children: "Abrindo o caderno…"
					}),
					hydrated && view === "notas" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesView, {}),
					hydrated && view === "alarme" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlarmsView, {}),
					hydrated && view === "tempo" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherView, {})
				]
			}),
			hydrated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "dock fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 backdrop-blur md:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, { variant: "dock" })
			}),
			hydrated && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scheduler, {})
		]
	});
}
function Header({ showNav }) {
	const now = useNow();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-20 border-b border-line bg-bg/90 px-4 py-4 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-2xl items-center justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-2xl font-semibold leading-none tracking-tight text-fg",
					children: ["appnote", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-accent",
						children: "SO"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 min-h-5 text-sm text-muted",
					children: now ? longDate(now) : "\xA0"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "shrink-0 font-display text-3xl font-semibold tabular-nums text-fg",
				children: now ? clock(now) : "--:--"
			})]
		}), showNav && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto mt-4 hidden max-w-2xl md:block",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, { variant: "bar" })
		})]
	});
}
function Nav({ variant }) {
	const view = useApp((state) => state.view);
	const setView = useApp((state) => state.setView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "Seções",
		className: variant === "dock" ? "mx-auto grid max-w-2xl grid-cols-3" : "flex w-fit gap-1 rounded-full bg-surface p-1",
		children: TABS.map(({ id, label, icon: Icon }) => {
			const active = view === id;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				"aria-current": active ? "page" : void 0,
				onClick: () => setView(id),
				className: variant === "dock" ? `flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-semibold ${active ? "text-accent" : "text-muted"}` : `h-11 rounded-full px-4 text-sm font-semibold ${active ? "bg-accent text-accent-ink" : "text-muted"}`,
				children: [variant === "dock" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-5",
					"aria-hidden": true
				}), label]
			}, id);
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {});
}
//#endregion
export { Home as component };
